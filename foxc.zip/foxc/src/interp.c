/* interp.c - FoxC agac-yurutmeli (tree-walking) yorumlayici */
#include "foxc.h"

static Env *g_global_env = NULL;

static Value call_func_obj(Obj *fo, Value *args, int argc);

Value interp_call_value(Value fn, Value *args, int argc) {
    if (fn.type == T_NATIVE) {
        int err = 0; char errmsg[256]; errmsg[0] = 0;
        Value r = fn.obj->native.fn(args, argc, &err, errmsg);
        if (err) {
            fprintf(stderr, "FoxC calisma zamani hatasi: %s\n", errmsg);
            exit(1);
        }
        return r;
    }
    if (fn.type == T_FUNC) return call_func_obj(fn.obj, args, argc);
    fprintf(stderr, "FoxC calisma zamani hatasi: cagrilabilir degil (%s)\n", type_name(fn));
    exit(1);
}

static Value call_func_obj(Obj *fo, Value *args, int argc) {
    Env *fenv = env_new(fo->func.closure);
    for (int i = 0; i < fo->func.nparams; i++) {
        Value av = (i < argc) ? args[i] : v_null();
        env_set_local(fenv, fo->func.params[i], av);
    }
    Signal sig; sig.active = 0; sig.kind = 0; sig.value = v_null();
    exec_block(fo->func.body, fenv, &sig);
    if (sig.active && sig.kind == 0) return sig.value;
    return v_null();
}

#define to_num value_num

static Value eval_binop(const char *op, Value a, Value b, int line) {
    if (strcmp(op, "+") == 0) {
        if (a.type == T_STR || b.type == T_STR) {
            char *as = value_to_cstring(a);
            char *bs = value_to_cstring(b);
            char *buf = (char*)malloc(strlen(as) + strlen(bs) + 1);
            strcpy(buf, as); strcat(buf, bs);
            free(as); free(bs);
            return v_str_take(buf);
        }
        if (a.type == T_ARR && b.type == T_ARR) {
            Value r = v_arr_new();
            for (int i = 0; i < a.obj->arr.count; i++) arr_push(r.obj, a.obj->arr.items[i]);
            for (int i = 0; i < b.obj->arr.count; i++) arr_push(r.obj, b.obj->arr.items[i]);
            return r;
        }
        return v_num(to_num(a) + to_num(b));
    }
    if (strcmp(op, "-") == 0) return v_num(to_num(a) - to_num(b));
    if (strcmp(op, "*") == 0) return v_num(to_num(a) * to_num(b));
    if (strcmp(op, "/") == 0) {
        double bn = to_num(b);
        if (bn == 0) { fprintf(stderr, "FoxC calisma zamani hatasi (satir %d): sifira bolme\n", line); exit(1); }
        return v_num(to_num(a) / bn);
    }
    if (strcmp(op, "%") == 0) {
        double bn = to_num(b);
        if (bn == 0) { fprintf(stderr, "FoxC calisma zamani hatasi (satir %d): sifira bolme (%%)\n", line); exit(1); }
        return v_num(fmod(to_num(a), bn));
    }
    if (strcmp(op, "==") == 0) return v_bool(values_equal(a, b));
    if (strcmp(op, "!=") == 0) return v_bool(!values_equal(a, b));
    if (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 || strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0) {
        if (a.type == T_STR && b.type == T_STR) {
            int c = strcmp(a.obj->str.chars, b.obj->str.chars);
            if (strcmp(op, "<") == 0) return v_bool(c < 0);
            if (strcmp(op, ">") == 0) return v_bool(c > 0);
            if (strcmp(op, "<=") == 0) return v_bool(c <= 0);
            return v_bool(c >= 0);
        }
        double an = to_num(a), bn = to_num(b);
        if (strcmp(op, "<") == 0) return v_bool(an < bn);
        if (strcmp(op, ">") == 0) return v_bool(an > bn);
        if (strcmp(op, "<=") == 0) return v_bool(an <= bn);
        return v_bool(an >= bn);
    }
    fprintf(stderr, "FoxC: bilinmeyen operator '%s'\n", op);
    exit(1);
}

static Node *find_pair_key(Node *pair) { return pair->a; }

Value eval_node(Node *n, Env *env, Signal *sig) {
    if (!n) return v_null();
    switch (n->type) {
        case N_NUM: return v_num(n->num);
        case N_STR: return v_str(n->str);
        case N_BOOL: return v_bool((int)n->num);
        case N_NULL: return v_null();
        case N_IDENT: {
            Value *v = env_get(env, n->str);
            if (!v) {
                fprintf(stderr, "FoxC calisma zamani hatasi (satir %d): tanimsiz degisken '%s'\n", n->line, n->str);
                exit(1);
            }
            return *v;
        }
        case N_ARRLIT: {
            Value r = v_arr_new();
            for (int i = 0; i < n->listcount; i++) {
                Value iv = eval_node(n->list[i], env, sig);
                if (sig->active) return v_null();
                arr_push(r.obj, iv);
            }
            return r;
        }
        case N_MAPLIT: {
            Value r = v_map_new();
            for (int i = 0; i < n->listcount; i++) {
                Node *pair = n->list[i];
                Value kv = eval_node(find_pair_key(pair), env, sig);
                if (sig->active) return v_null();
                char *ks = value_to_cstring(kv);
                Value vv = eval_node(pair->b, env, sig);
                if (sig->active) { free(ks); return v_null(); }
                map_set(r.obj, ks, vv);
                free(ks);
            }
            return r;
        }
        case N_UNOP: {
            Value a = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            if (strcmp(n->str, "-") == 0) return v_num(-to_num(a));
            if (strcmp(n->str, "+") == 0) return v_num(to_num(a));
            if (strcmp(n->str, "!") == 0) return v_bool(!is_truthy(a));
            return v_null();
        }
        case N_BINOP: {
            Value a = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            Value b = eval_node(n->b, env, sig);
            if (sig->active) return v_null();
            return eval_binop(n->str, a, b, n->line);
        }
        case N_LOGICAL: {
            Value a = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            if (strcmp(n->str, "&&") == 0) {
                if (!is_truthy(a)) return a;
                return eval_node(n->b, env, sig);
            } else {
                if (is_truthy(a)) return a;
                return eval_node(n->b, env, sig);
            }
        }
        case N_ASSIGN: {
            Value v = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            if (!env_assign(env, n->str, v)) env_set_local(g_global_env, n->str, v);
            return v;
        }
        case N_INDEXASSIGN: {
            Value base = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            Value idx = eval_node(n->b, env, sig);
            if (sig->active) return v_null();
            Value val = eval_node(n->c, env, sig);
            if (sig->active) return v_null();
            if (base.type == T_ARR) {
                int i = (int)to_num(idx);
                if (i < 0) i += base.obj->arr.count;
                while (i >= base.obj->arr.count) arr_push(base.obj, v_null());
                if (i >= 0 && i < base.obj->arr.count) base.obj->arr.items[i] = val;
            } else if (base.type == T_MAP) {
                char *ks = value_to_cstring(idx);
                map_set(base.obj, ks, val);
                free(ks);
            } else {
                fprintf(stderr, "FoxC calisma zamani hatasi: indeksleme atamasi dizi/harita uzerinde olmali\n");
                exit(1);
            }
            return val;
        }
        case N_MEMBERASSIGN: {
            Value base = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            Value val = eval_node(n->c, env, sig);
            if (sig->active) return v_null();
            if (base.type == T_MAP) map_set(base.obj, n->str, val);
            else { fprintf(stderr, "FoxC calisma zamani hatasi: alan atamasi harita uzerinde olmali\n"); exit(1); }
            return val;
        }
        case N_INDEX: {
            Value base = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            Value idx = eval_node(n->b, env, sig);
            if (sig->active) return v_null();
            if (base.type == T_ARR) return arr_get(base.obj, (int)to_num(idx));
            if (base.type == T_STR) {
                int i = (int)to_num(idx);
                if (i < 0) i += base.obj->str.len;
                if (i < 0 || i >= base.obj->str.len) return v_null();
                char buf[2] = { base.obj->str.chars[i], 0 };
                return v_str(buf);
            }
            if (base.type == T_MAP) {
                char *ks = value_to_cstring(idx);
                Value *r = map_get(base.obj, ks);
                free(ks);
                return r ? *r : v_null();
            }
            return v_null();
        }
        case N_MEMBER: {
            Value base = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            if (base.type == T_MAP) {
                Value *r = map_get(base.obj, n->str);
                return r ? *r : v_null();
            }
            return v_null();
        }
        case N_FUNCEXPR: {
            FuncObj fo; memset(&fo, 0, sizeof(fo));
            fo.nparams = n->listcount;
            fo.params = (char**)malloc(sizeof(char*) * (fo.nparams ? fo.nparams : 1));
            for (int i = 0; i < fo.nparams; i++) fo.params[i] = n->list[i]->str;
            fo.body = n->a;
            fo.closure = env;
            fo.name = "anonim";
            return v_func(fo);
        }
        case N_CALL: {
            Value fn = eval_node(n->a, env, sig);
            if (sig->active) return v_null();
            int argc = n->listcount;
            Value *args = (Value*)malloc(sizeof(Value) * (argc ? argc : 1));
            for (int i = 0; i < argc; i++) {
                args[i] = eval_node(n->list[i], env, sig);
                if (sig->active) { free(args); return v_null(); }
            }
            Value r = interp_call_value(fn, args, argc);
            free(args);
            return r;
        }
        default:
            return v_null();
    }
}

static void exec_stmt(Node *n, Env *env, Signal *sig) {
    if (!n || sig->active) return;
    switch (n->type) {
        case N_VARDECL: {
            Value v = n->a ? eval_node(n->a, env, sig) : v_null();
            if (sig->active) return;
            env_set_local(env, n->str, v);
            return;
        }
        case N_FUNCDECL: {
            FuncObj fo; memset(&fo, 0, sizeof(fo));
            fo.nparams = n->listcount;
            fo.params = (char**)malloc(sizeof(char*) * (fo.nparams ? fo.nparams : 1));
            for (int i = 0; i < fo.nparams; i++) fo.params[i] = n->list[i]->str;
            fo.body = n->a;
            fo.closure = env;
            fo.name = n->str;
            Value fv = v_func(fo);
            env_set_local(env, n->str, fv);
            return;
        }
        case N_IF: {
            Value c = eval_node(n->a, env, sig);
            if (sig->active) return;
            if (is_truthy(c)) {
                Env *blockenv = env_new(env);
                exec_block(n->b, blockenv, sig);
            } else if (n->c) {
                if (n->c->type == N_BLOCK) {
                    Env *blockenv = env_new(env);
                    exec_block(n->c, blockenv, sig);
                } else exec_stmt(n->c, env, sig);
            }
            return;
        }
        case N_WHILE: {
            while (!sig->active) {
                Value c = eval_node(n->a, env, sig);
                if (sig->active) return;
                if (!is_truthy(c)) break;
                Env *blockenv = env_new(env);
                exec_block(n->b, blockenv, sig);
                if (sig->active) {
                    if (sig->kind == 1) { sig->active = 0; break; } /* break */
                    if (sig->kind == 2) { sig->active = 0; continue; } /* continue */
                    return; /* return propagates */
                }
            }
            return;
        }
        case N_FOR: {
            Env *forenv = env_new(env);
            if (n->a) exec_stmt(n->a, forenv, sig);
            if (sig->active) return;
            for (;;) {
                if (n->b) {
                    Value c = eval_node(n->b, forenv, sig);
                    if (sig->active) return;
                    if (!is_truthy(c)) break;
                }
                Env *blockenv = env_new(forenv);
                exec_block(n->d, blockenv, sig);
                if (sig->active) {
                    if (sig->kind == 1) { sig->active = 0; break; }
                    if (sig->kind == 2) { sig->active = 0; }
                    else return;
                }
                if (n->c) {
                    eval_node(n->c, forenv, sig);
                    if (sig->active) return;
                }
            }
            return;
        }
        case N_RETURN: {
            Value v = n->a ? eval_node(n->a, env, sig) : v_null();
            if (sig->active) return;
            sig->active = 1; sig->kind = 0; sig->value = v;
            return;
        }
        case N_BREAK:
            sig->active = 1; sig->kind = 1; sig->value = v_null();
            return;
        case N_CONTINUE:
            sig->active = 1; sig->kind = 2; sig->value = v_null();
            return;
        case N_BLOCK: {
            Env *blockenv = env_new(env);
            exec_block(n, blockenv, sig);
            return;
        }
        case N_EXPRSTMT: {
            eval_node(n->a, env, sig);
            return;
        }
        default:
            eval_node(n, env, sig);
            return;
    }
}

void exec_block(Node *n, Env *env, Signal *sig) {
    for (int i = 0; i < n->listcount && !sig->active; i++) {
        exec_stmt(n->list[i], env, sig);
    }
}

Value interp_run(Node *program, Env *global) {
    g_global_env = global;
    Signal sig; sig.active = 0; sig.kind = 0; sig.value = v_null();
    for (int i = 0; i < program->listcount; i++) {
        exec_stmt(program->list[i], global, &sig);
        if (sig.active) {
            if (sig.kind == 0) return sig.value; /* top-level return ends program */
            sig.active = 0; /* ignore stray break/continue at top level */
        }
    }
    return v_null();
}
