/* main.c - FoxC betik calistirici */
#include "foxc.h"

static char *read_file_all(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "FoxC: dosya acilamadi: %s\n", path); exit(1); }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = (char*)malloc(sz + 1);
    size_t rd = fread(buf, 1, sz, f);
    buf[rd] = 0;
    fclose(f);
    return buf;
}

int main(int argc, char **argv) {
    if (argc >= 2 && strcmp(argv[1], "--count") == 0) {
        Env *g = env_new(NULL);
        builtins_register(g);
        printf("%d\n", builtins_total_count());
        return 0;
    }
    if (argc < 2) {
        fprintf(stderr, "Kullanim: %s <betik.foxc>\n", argv[0]);
        fprintf(stderr, "          %s --count   (yerlesik fonksiyon sayisini yazdirir)\n", argv[0]);
        return 1;
    }
    char *src = read_file_all(argv[1]);
    Parser p;
    parser_init(&p, src);
    Node *prog = parse_program(&p);

    Env *global = env_new(NULL);
    builtins_register(global);

    /* betik argumanlari: komut_satiri_argumanlari */
    Value argsv = v_arr_new();
    for (int i = 2; i < argc; i++) arr_push(argsv.obj, v_str(argv[i]));
    env_set_local(global, "komut_satiri_argumanlari", argsv);

    interp_run(prog, global);

    free(src);
    return 0;
}
