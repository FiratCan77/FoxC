/* FoxC - gelismis, C ile yazilmis bir betik dili.
 * Sozdizimi: { } blok, " " string, : map/sozluk anahtar-deger ayraci.
 */
#ifndef FOXC_H
#define FOXC_H

#define _GNU_SOURCE
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif

/* ---------------- Deger (Value) sistemi ---------------- */

typedef enum {
    T_NULL, T_BOOL, T_NUM, T_STR, T_ARR, T_MAP, T_FUNC, T_NATIVE
} ValType;

typedef struct Value Value;
typedef struct Obj Obj;
typedef struct Env Env;
typedef struct Node Node;

typedef struct { char *key; Value *val; } MapEntry;

typedef struct {
    ValType type;
    union {
        int b;
        double num;
        Obj *obj;
    };
} ValueU; /* internal union helper (kept for clarity) */

struct Value {
    ValType type;
    int b;
    double num;
    Obj *obj;
};

typedef struct {
    char *chars;
    int len;
} StrObj;

typedef struct {
    Value *items;
    int count, cap;
} ArrObj;

typedef struct {
    MapEntry *entries;
    int count, cap;
} MapObj;

typedef struct {
    char **params;
    int nparams;
    Node *body;
    Env *closure;
    char *name;
} FuncObj;

typedef Value (*NativeFn)(Value *args, int argc, int *err, char *errmsg);

typedef struct {
    const char *name;
    NativeFn fn;
} NativeObj;

struct Obj {
    int type; /* mirrors ValType for T_STR/T_ARR/T_MAP/T_FUNC/T_NATIVE */
    union {
        StrObj str;
        ArrObj arr;
        MapObj map;
        FuncObj func;
        NativeObj native;
    };
};

/* ---------------- Ortam (Environment) ---------------- */

typedef struct VarSlot { char *name; Value val; } VarSlot;

struct Env {
    VarSlot *vars;
    int count, cap;
    Env *parent;
};

Env *env_new(Env *parent);
Value *env_get(Env *e, const char *name);
void env_set_local(Env *e, const char *name, Value v);
int env_assign(Env *e, const char *name, Value v); /* walks up scopes */

/* ---------------- Lexer ---------------- */

typedef enum {
    TK_EOF, TK_NUM, TK_STR, TK_IDENT,
    TK_LBRACE, TK_RBRACE, TK_LPAREN, TK_RPAREN, TK_LBRACKET, TK_RBRACKET,
    TK_COLON, TK_COMMA, TK_SEMI, TK_DOT,
    TK_PLUS, TK_MINUS, TK_STAR, TK_SLASH, TK_PERCENT,
    TK_ASSIGN, TK_EQ, TK_NEQ, TK_LT, TK_GT, TK_LE, TK_GE,
    TK_AND, TK_OR, TK_NOT,
    TK_FN, TK_VAR, TK_IF, TK_ELSE, TK_WHILE, TK_FOR, TK_RETURN,
    TK_TRUE, TK_FALSE, TK_NULLTOK, TK_BREAK, TK_CONTINUE,
    TK_PLUSPLUS, TK_MINUSMINUS, TK_PLUSEQ, TK_MINUSEQ, TK_STAREQ, TK_SLASHEQ
} TokType;

typedef struct {
    TokType type;
    char *text;   /* owned copy for ident/string */
    double num;
    int line;
} Token;

typedef struct {
    const char *src;
    int pos, line, len;
} Lexer;

void lexer_init(Lexer *lx, const char *src);
Token lexer_next(Lexer *lx);

/* ---------------- AST ---------------- */

typedef enum {
    N_NUM, N_STR, N_BOOL, N_NULL, N_IDENT,
    N_ARRLIT, N_MAPLIT,
    N_BINOP, N_UNOP, N_LOGICAL,
    N_ASSIGN, N_INDEXASSIGN, N_MEMBERASSIGN,
    N_VARDECL,
    N_IF, N_WHILE, N_FOR, N_FORIN,
    N_FUNCDECL, N_CALL, N_RETURN, N_BLOCK,
    N_INDEX, N_MEMBER,
    N_BREAK, N_CONTINUE, N_EXPRSTMT, N_PROGRAM,
    N_FUNCEXPR
} NodeType;

struct Node {
    NodeType type;
    int line;
    /* generic payload fields, used differently per node type */
    double num;
    char *str;         /* ident name / string literal / op text */
    Node *a, *b, *c, *d; /* children: meaning depends on node type */
    Node **list;        /* list of children (args, params as idents via str, stmts) */
    int listcount, listcap;
};

Node *node_new(NodeType t);
void node_list_push(Node *n, Node *child);

typedef struct {
    Lexer lx;
    Token cur, prev;
} Parser;

void parser_init(Parser *p, const char *src);
Node *parse_program(Parser *p);

/* ---------------- Yorumlayici (Interpreter) ---------------- */

typedef struct {
    int active;   /* 1 if a control-flow signal is in effect */
    int kind;     /* 0=return 1=break 2=continue */
    Value value;
} Signal;

Value interp_run(Node *program, Env *global);
Value interp_call_value(Value fn, Value *args, int argc);
Value eval_node(Node *n, Env *env, Signal *sig);
void exec_block(Node *n, Env *env, Signal *sig);

/* ---------------- Yardimci Deger fonksiyonlari ---------------- */

Value v_null(void);
Value v_bool(int b);
Value v_num(double d);
Value v_str(const char *s);
Value v_str_take(char *s); /* takes ownership of malloc'd buffer */
Value v_arr_new(void);
Value v_map_new(void);
Value v_func(FuncObj f);
Value v_native(const char *name, NativeFn fn);

double value_num(Value v); /* sayisal donusum: num/bool/string->sayi */
int is_truthy(Value v);
int values_equal(Value a, Value b);
char *value_to_cstring(Value v); /* caller frees */
const char *type_name(Value v);
void value_print(Value v, int newline);

void arr_push(Obj *o, Value v);
Value arr_get(Obj *o, int idx);
void map_set(Obj *o, const char *key, Value v);
Value *map_get(Obj *o, const char *key);

/* ---------------- Builtins ---------------- */

typedef struct {
    const char *name;
    NativeFn fn;
} BuiltinEntry;

extern BuiltinEntry g_builtins[];
extern int g_builtin_count;
void builtins_register(Env *global);
int builtins_total_count(void);

/* global RNG seed state */
extern unsigned long g_rng_state;

#endif
