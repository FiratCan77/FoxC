/* builtins.c - FoxC yerlesik (built-in) fonksiyon kutuphanesi
 * 320+ fonksiyon: matematik, metin, dizi, harita, dosya/sistem, tur,
 * cihaz(Termux), bit, json, hash, istatistik, geometri, renk, zaman, rastgele.
 */
#include "foxc.h"
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>

extern char **environ;

#define NA(i) value_num(args[i])
#define SA(i) (args[i].type==T_STR ? args[i].obj->str.chars : "")
#define HAS(i) (argc > (i))
#define OK (void)err; (void)errmsg;

static unsigned long xorshift(void) {
    g_rng_state ^= g_rng_state << 13;
    g_rng_state ^= g_rng_state >> 7;
    g_rng_state ^= g_rng_state << 17;
    return g_rng_state;
}
static double rnd01(void) { return (double)(xorshift() % 1000000000UL) / 1000000000.0; }

static int value_less(Value a, Value b) {
    if (a.type == T_STR && b.type == T_STR) return strcmp(a.obj->str.chars, b.obj->str.chars) < 0;
    return value_num(a) < value_num(b);
}

int deep_equals_value(Value a, Value b) {
    if (a.type != b.type) {
        if (a.type == T_NUM && b.type == T_NUM) return a.num == b.num;
        return 0;
    }
    if (a.type == T_MAP) {
        if (a.obj->map.count != b.obj->map.count) return 0;
        for (int i = 0; i < a.obj->map.count; i++) {
            Value *bv = map_get(b.obj, a.obj->map.entries[i].key);
            if (!bv || !deep_equals_value(*(a.obj->map.entries[i].val), *bv)) return 0;
        }
        return 1;
    }
    if (a.type == T_ARR) {
        if (a.obj->arr.count != b.obj->arr.count) return 0;
        for (int i = 0; i < a.obj->arr.count; i++)
            if (!deep_equals_value(a.obj->arr.items[i], b.obj->arr.items[i])) return 0;
        return 1;
    }
    return values_equal(a, b);
}

static Value deep_copy_value(Value v) {
    if (v.type == T_ARR) {
        Value r = v_arr_new();
        for (int i = 0; i < v.obj->arr.count; i++) arr_push(r.obj, deep_copy_value(v.obj->arr.items[i]));
        return r;
    }
    if (v.type == T_MAP) {
        Value r = v_map_new();
        for (int i = 0; i < v.obj->map.count; i++)
            map_set(r.obj, v.obj->map.entries[i].key, deep_copy_value(*(v.obj->map.entries[i].val)));
        return r;
    }
    if (v.type == T_STR) return v_str(v.obj->str.chars);
    return v;
}

static char *dup_range(const char *s, int start, int end) {
    int len = (int)strlen(s);
    if (start < 0) start += len;
    if (end < 0) end += len;
    if (start < 0) start = 0;
    if (end > len) end = len;
    if (start > end) start = end;
    int n = end - start;
    char *buf = (char*)malloc(n + 1);
    memcpy(buf, s + start, n);
    buf[n] = 0;
    return buf;
}

static Value read_whole_file(const char *path, int *okflag) {
    FILE *f = fopen(path, "rb");
    if (!f) { *okflag = 0; return v_null(); }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = (char*)malloc(sz + 1);
    size_t rd = fread(buf, 1, sz, f);
    buf[rd] = 0;
    fclose(f);
    *okflag = 1;
    return v_str_take(buf);
}

static Value popen_capture(const char *cmd) {
    FILE *p = popen(cmd, "r");
    if (!p) return v_str("");
    size_t cap = 1024, len = 0;
    char *buf = (char*)malloc(cap);
    size_t n;
    char chunk[512];
    while ((n = fread(chunk, 1, sizeof(chunk), p)) > 0) {
        while (len + n + 1 > cap) { cap *= 2; buf = (char*)realloc(buf, cap); }
        memcpy(buf + len, chunk, n);
        len += n;
    }
    buf[len] = 0;
    pclose(p);
    /* trailing newline temizle */
    while (len > 0 && (buf[len-1] == '\n' || buf[len-1] == '\r')) buf[--len] = 0;
    return v_str_take(buf);
}

/* ========================= MATEMATIK (tek argumanli, libm) ========================= */

#define MATH1(nm, cfunc) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    OK if (argc < 1) return v_num(0); \
    return v_num(cfunc(NA(0))); \
}

MATH1(sqrt, sqrt) MATH1(sin, sin) MATH1(cos, cos) MATH1(tan, tan)
MATH1(asin, asin) MATH1(acos, acos) MATH1(atan, atan)
MATH1(sinh, sinh) MATH1(cosh, cosh) MATH1(tanh, tanh)
MATH1(log, log) MATH1(log2, log2) MATH1(log10, log10) MATH1(log1p, log1p)
MATH1(exp, exp) MATH1(exp2, exp2) MATH1(cbrt, cbrt)
MATH1(abs, fabs) MATH1(floor, floor) MATH1(ceil, ceil) MATH1(round, round)
MATH1(trunc, trunc) MATH1(expm1, expm1) MATH1(erf, erf) MATH1(erfc, erfc) MATH1(tgamma, tgamma)

#define MATH2(nm, cfunc) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    OK if (argc < 2) return v_num(0); \
    return v_num(cfunc(NA(0), NA(1))); \
}

MATH2(pow, pow) MATH2(atan2, atan2) MATH2(fmod, fmod) MATH2(hypot, hypot)
MATH2(copysign, copysign) MATH2(fmax, fmax) MATH2(fmin, fmin)
MATH2(fdim, fdim) MATH2(nextafter, nextafter)

/* ========================= MATEMATIK (ozel) ========================= */

static Value bi_sign(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    double x = NA(0); return v_num(x > 0 ? 1 : (x < 0 ? -1 : 0));
}
static Value bi_clamp(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_num(0);
    double x = NA(0), lo = NA(1), hi = NA(2);
    if (x < lo) x = lo; if (x > hi) x = hi; return v_num(x);
}
static Value bi_clamp01(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    double x = NA(0); if (x < 0) x = 0; if (x > 1) x = 1; return v_num(x);
}
static Value bi_min(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    double a = NA(0), b = NA(1); return v_num(a < b ? a : b);
}
static Value bi_max(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    double a = NA(0), b = NA(1); return v_num(a > b ? a : b);
}
static Value bi_mod(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    double a = NA(0), b = NA(1);
    if (b == 0) { *err = 1; snprintf(errmsg, 256, "mod: sifira bolme"); return v_null(); }
    double r = fmod(a, b); if (r != 0 && ((r < 0) != (b < 0))) r += b;
    return v_num(r);
}
static Value bi_gcd(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    long long a = (long long)NA(0), b = (long long)NA(1);
    if (a < 0) a = -a; if (b < 0) b = -b;
    while (b) { long long t = b; b = a % b; a = t; }
    return v_num((double)a);
}
static Value bi_lcm(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    long long a = (long long)NA(0), b = (long long)NA(1);
    if (a == 0 || b == 0) return v_num(0);
    long long aa = a < 0 ? -a : a, bb = b < 0 ? -b : b, x = aa, y = bb;
    while (y) { long long t = y; y = x % y; x = t; }
    return v_num((double)((aa / x) * bb));
}
static Value bi_factorial(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(1);
    long long n = (long long)NA(0);
    if (n < 0) { *err = 1; snprintf(errmsg, 256, "factorial: negatif sayi"); return v_null(); }
    double r = 1; for (long long i = 2; i <= n; i++) r *= i;
    return v_num(r);
}
static Value bi_is_prime(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    long long n = (long long)NA(0);
    if (n < 2) return v_bool(0);
    for (long long i = 2; i * i <= n; i++) if (n % i == 0) return v_bool(0);
    return v_bool(1);
}
static Value bi_deg2rad(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(NA(0) * M_PI / 180.0);
}
static Value bi_rad2deg(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(NA(0) * 180.0 / M_PI);
}
static Value bi_random(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_num(rnd01());
}
static Value bi_random_range(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    double lo = NA(0), hi = NA(1); return v_num(lo + rnd01() * (hi - lo));
}
static Value bi_random_seed(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    g_rng_state = (unsigned long)NA(0) | 1UL; return v_null();
}
static Value bi_nth_root(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    return v_num(pow(NA(0), 1.0 / NA(1)));
}
static Value bi_is_even(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(((long long)NA(0)) % 2 == 0);
}
static Value bi_is_odd(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(((long long)NA(0)) % 2 != 0);
}
static Value bi_is_power_of_two(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    long long n = (long long)NA(0); return v_bool(n > 0 && (n & (n - 1)) == 0);
}
static Value bi_digit_sum(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    long long n = (long long)NA(0); if (n < 0) n = -n;
    long long s = 0; if (n == 0) s = 0; while (n > 0) { s += n % 10; n /= 10; }
    return v_num((double)s);
}
static Value bi_reverse_number(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    long long n = (long long)NA(0); int neg = n < 0; if (neg) n = -n;
    long long r = 0; while (n > 0) { r = r * 10 + n % 10; n /= 10; }
    return v_num((double)(neg ? -r : r));
}
static char *to_base_str(unsigned long long n, int base) {
    char tmp[70]; int i = 0;
    if (n == 0) tmp[i++] = '0';
    const char *digits = "0123456789abcdef";
    while (n > 0) { tmp[i++] = digits[n % base]; n /= base; }
    char *out = (char*)malloc(i + 1);
    for (int j = 0; j < i; j++) out[j] = tmp[i - 1 - j];
    out[i] = 0;
    return out;
}
static Value bi_to_binary_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("0"); return v_str_take(to_base_str((unsigned long long)NA(0), 2));
}
static Value bi_to_hex_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("0"); return v_str_take(to_base_str((unsigned long long)NA(0), 16));
}
static Value bi_to_octal_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("0"); return v_str_take(to_base_str((unsigned long long)NA(0), 8));
}
static Value bi_from_base(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    return v_num((double)strtoll(SA(0), NULL, (int)NA(1)));
}
static Value bi_pi(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_num(M_PI);
}
static Value bi_e(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_num(M_E);
}
static Value bi_lerp(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_num(0);
    double a = NA(0), b = NA(1), t = NA(2); return v_num(a + (b - a) * t);
}
static Value bi_inverse_lerp(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_num(0);
    double a = NA(0), b = NA(1), v = NA(2);
    if (b == a) return v_num(0);
    return v_num((v - a) / (b - a));
}
static Value bi_lerp_angle(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_num(0);
    double a = NA(0), b = NA(1), t = NA(2);
    double diff = fmod(b - a + 180.0, 360.0); if (diff < 0) diff += 360.0; diff -= 180.0;
    return v_num(a + diff * t);
}

/* ========================= METIN (string) ========================= */

static Value bi_upper(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char *s = strdup(SA(0)); for (char *p = s; *p; p++) *p = toupper((unsigned char)*p);
    return v_str_take(s);
}
static Value bi_lower(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char *s = strdup(SA(0)); for (char *p = s; *p; p++) *p = tolower((unsigned char)*p);
    return v_str_take(s);
}
static char *trim_impl(const char *s, int left, int right) {
    int len = (int)strlen(s), a = 0, b = len;
    if (left) while (a < b && isspace((unsigned char)s[a])) a++;
    if (right) while (b > a && isspace((unsigned char)s[b-1])) b--;
    char *out = (char*)malloc(b - a + 1);
    memcpy(out, s + a, b - a); out[b - a] = 0;
    return out;
}
static Value bi_trim(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(""); return v_str_take(trim_impl(SA(0), 1, 1));
}
static Value bi_ltrim(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(""); return v_str_take(trim_impl(SA(0), 1, 0));
}
static Value bi_rtrim(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(""); return v_str_take(trim_impl(SA(0), 0, 1));
}
static Value bi_split(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_arr_new();
    const char *s = SA(0), *sep = SA(1);
    Value r = v_arr_new();
    if (*sep == 0) {
        for (int i = 0; s[i]; i++) { char buf[2] = { s[i], 0 }; arr_push(r.obj, v_str(buf)); }
        return r;
    }
    int seplen = (int)strlen(sep);
    const char *start = s, *p;
    while ((p = strstr(start, sep)) != NULL) {
        int n = (int)(p - start);
        char *piece = (char*)malloc(n + 1); memcpy(piece, start, n); piece[n] = 0;
        arr_push(r.obj, v_str_take(piece));
        start = p + seplen;
    }
    arr_push(r.obj, v_str(start));
    return r;
}
static Value bi_replace(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("");
    const char *s = SA(0), *from = SA(1), *to = SA(2);
    char *p = strstr(s, from);
    if (!p || *from == 0) return v_str(s);
    int prefix = (int)(p - s);
    int flen = (int)strlen(from), tlen = (int)strlen(to), slen = (int)strlen(s);
    char *out = (char*)malloc(slen - flen + tlen + 1);
    memcpy(out, s, prefix);
    memcpy(out + prefix, to, tlen);
    strcpy(out + prefix + tlen, s + prefix + flen);
    return v_str_take(out);
}
static Value bi_replace_all(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("");
    const char *s = SA(0), *from = SA(1), *to = SA(2);
    if (*from == 0) return v_str(s);
    size_t cap = strlen(s) + 64, len = 0;
    char *out = (char*)malloc(cap);
    int flen = (int)strlen(from), tlen = (int)strlen(to);
    const char *cur = s;
    while (1) {
        const char *p = strstr(cur, from);
        const char *end = p ? p : cur + strlen(cur);
        int chunk = (int)(end - cur);
        while (len + chunk + tlen + 1 > cap) { cap *= 2; out = (char*)realloc(out, cap); }
        memcpy(out + len, cur, chunk); len += chunk;
        if (!p) break;
        memcpy(out + len, to, tlen); len += tlen;
        cur = p + flen;
    }
    out[len] = 0;
    return v_str_take(out);
}
static Value bi_substr(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0);
    int start = (int)NA(1);
    int end = HAS(2) ? (int)NA(2) : (int)strlen(s);
    return v_str_take(dup_range(s, start, end));
}
static Value bi_index_of(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(-1);
    if (args[0].type == T_ARR) {
        for (int i = 0; i < args[0].obj->arr.count; i++)
            if (values_equal(args[0].obj->arr.items[i], args[1])) return v_num(i);
        return v_num(-1);
    }
    const char *s = SA(0), *needle = SA(1);
    char *p = strstr(s, needle);
    return v_num(p ? (double)(p - s) : -1);
}
static Value bi_last_index_of(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(-1);
    const char *s = SA(0), *needle = SA(1);
    if (*needle == 0) return v_num((double)strlen(s));
    const char *last = NULL, *cur = s, *p;
    while ((p = strstr(cur, needle)) != NULL) { last = p; cur = p + 1; }
    return v_num(last ? (double)(last - s) : -1);
}
static Value bi_contains(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    if (args[0].type == T_ARR) {
        for (int i = 0; i < args[0].obj->arr.count; i++)
            if (values_equal(args[0].obj->arr.items[i], args[1])) return v_bool(1);
        return v_bool(0);
    }
    return v_bool(strstr(SA(0), SA(1)) != NULL);
}
static Value bi_starts_with(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    const char *s = SA(0), *pre = SA(1);
    return v_bool(strncmp(s, pre, strlen(pre)) == 0);
}
static Value bi_ends_with(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    const char *s = SA(0), *suf = SA(1);
    int sl = (int)strlen(s), fl = (int)strlen(suf);
    if (fl > sl) return v_bool(0);
    return v_bool(strcmp(s + sl - fl, suf) == 0);
}
static Value bi_reverse(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    if (args[0].type == T_ARR) {
        Value r = v_arr_new();
        for (int i = args[0].obj->arr.count - 1; i >= 0; i--) arr_push(r.obj, args[0].obj->arr.items[i]);
        return r;
    }
    const char *s = SA(0); int n = (int)strlen(s);
    char *out = (char*)malloc(n + 1);
    for (int i = 0; i < n; i++) out[i] = s[n - 1 - i];
    out[n] = 0;
    return v_str_take(out);
}
static Value bi_repeat(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int n = (int)NA(1); if (n < 0) n = 0;
    int slen = (int)strlen(s);
    char *out = (char*)malloc((size_t)slen * n + 1);
    out[0] = 0;
    for (int i = 0; i < n; i++) strcat(out, s);
    return v_str_take(out);
}
static Value bi_pad_left(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int width = (int)NA(1);
    char padc = HAS(2) ? SA(2)[0] : ' ';
    int slen = (int)strlen(s);
    if (slen >= width) return v_str(s);
    char *out = (char*)malloc(width + 1);
    int padn = width - slen;
    memset(out, padc, padn);
    memcpy(out + padn, s, slen);
    out[width] = 0;
    return v_str_take(out);
}
static Value bi_pad_right(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int width = (int)NA(1);
    char padc = HAS(2) ? SA(2)[0] : ' ';
    int slen = (int)strlen(s);
    if (slen >= width) return v_str(s);
    char *out = (char*)malloc(width + 1);
    memcpy(out, s, slen);
    memset(out + slen, padc, width - slen);
    out[width] = 0;
    return v_str_take(out);
}
static Value bi_concat(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_null();
    if (args[0].type == T_ARR && args[1].type == T_ARR) {
        Value r = v_arr_new();
        for (int i = 0; i < args[0].obj->arr.count; i++) arr_push(r.obj, args[0].obj->arr.items[i]);
        for (int i = 0; i < args[1].obj->arr.count; i++) arr_push(r.obj, args[1].obj->arr.items[i]);
        return r;
    }
    char *a = value_to_cstring(args[0]), *b = value_to_cstring(args[1]);
    char *out = (char*)malloc(strlen(a) + strlen(b) + 1);
    strcpy(out, a); strcat(out, b);
    free(a); free(b);
    return v_str_take(out);
}
static Value bi_format(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *fmt = SA(0);
    size_t cap = strlen(fmt) + 64, len = 0;
    char *out = (char*)malloc(cap);
    int argi = 1;
    for (const char *p = fmt; *p; p++) {
        if (*p == '{' && *(p+1) == '}') {
            p++;
            char *piece = argi < argc ? value_to_cstring(args[argi]) : strdup("");
            argi++;
            size_t plen = strlen(piece);
            while (len + plen + 1 > cap) { cap *= 2; out = (char*)realloc(out, cap); }
            memcpy(out + len, piece, plen); len += plen;
            free(piece);
        } else {
            if (len + 2 > cap) { cap *= 2; out = (char*)realloc(out, cap); }
            out[len++] = *p;
        }
    }
    out[len] = 0;
    return v_str_take(out);
}
static Value bi_capitalize(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char *s = strdup(SA(0));
    if (s[0]) s[0] = toupper((unsigned char)s[0]);
    return v_str_take(s);
}
static Value bi_title_case(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char *s = strdup(SA(0));
    int newword = 1;
    for (char *p = s; *p; p++) {
        if (isspace((unsigned char)*p)) { newword = 1; }
        else { *p = newword ? toupper((unsigned char)*p) : tolower((unsigned char)*p); newword = 0; }
    }
    return v_str_take(s);
}
static Value bi_count_occurrences(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    const char *s = SA(0), *needle = SA(1);
    if (*needle == 0) return v_num(0);
    int count = 0; const char *cur = s, *p;
    int nlen = (int)strlen(needle);
    while ((p = strstr(cur, needle)) != NULL) { count++; cur = p + nlen; }
    return v_num(count);
}
static Value bi_is_empty(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(1);
    Value v = args[0];
    if (v.type == T_NULL) return v_bool(1);
    if (v.type == T_STR) return v_bool(v.obj->str.len == 0);
    if (v.type == T_ARR) return v_bool(v.obj->arr.count == 0);
    if (v.type == T_MAP) return v_bool(v.obj->map.count == 0);
    return v_bool(0);
}
static Value bi_is_numeric(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    const char *s = SA(0); if (!*s) return v_bool(0);
    char *endp; strtod(s, &endp);
    return v_bool(*endp == 0);
}
#define CTYPE_CHECK(nm, pred) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    OK if (argc < 1) return v_bool(0); \
    const char *s = SA(0); if (!*s) return v_bool(0); \
    for (const char *p = s; *p; p++) if (!pred((unsigned char)*p)) return v_bool(0); \
    return v_bool(1); \
}
CTYPE_CHECK(is_alpha, isalpha)
CTYPE_CHECK(is_alnum, isalnum)
CTYPE_CHECK(is_digit, isdigit)
CTYPE_CHECK(is_space, isspace)
CTYPE_CHECK(is_upper, isupper)
CTYPE_CHECK(is_lower, islower)

static Value bi_char_at(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int i = (int)NA(1), len = (int)strlen(s);
    if (i < 0) i += len;
    if (i < 0 || i >= len) return v_str("");
    char buf[2] = { s[i], 0 }; return v_str(buf);
}
static Value bi_char_code_at(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(-1);
    const char *s = SA(0); int i = (int)NA(1), len = (int)strlen(s);
    if (i < 0 || i >= len) return v_num(-1);
    return v_num((unsigned char)s[i]);
}
static Value bi_from_char_code(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char buf[2] = { (char)(int)NA(0), 0 }; return v_str(buf);
}
static Value bi_strip_chars(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0), *chars = SA(1);
    char *out = (char*)malloc(strlen(s) + 1);
    int j = 0;
    for (const char *p = s; *p; p++) if (!strchr(chars, *p)) out[j++] = *p;
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_insert_at(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("");
    const char *s = SA(0); int i = (int)NA(1); const char *ins = SA(2);
    int slen = (int)strlen(s), ilen = (int)strlen(ins);
    if (i < 0) i = 0; if (i > slen) i = slen;
    char *out = (char*)malloc(slen + ilen + 1);
    memcpy(out, s, i);
    memcpy(out + i, ins, ilen);
    strcpy(out + i + ilen, s + i);
    return v_str_take(out);
}
static Value bi_remove_range(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("");
    const char *s = SA(0); int start = (int)NA(1), end = (int)NA(2);
    int slen = (int)strlen(s);
    if (start < 0) start = 0; if (end > slen) end = slen; if (start > end) start = end;
    char *out = (char*)malloc(slen - (end - start) + 1);
    memcpy(out, s, start);
    strcpy(out + start, s + end);
    return v_str_take(out);
}
static Value bi_to_int(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    if (args[0].type == T_STR) return v_num((double)(long long)atof(args[0].obj->str.chars));
    return v_num((double)(long long)NA(0));
}
static Value bi_to_float(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    if (args[0].type == T_STR) return v_num(atof(args[0].obj->str.chars));
    return v_num(NA(0));
}
static Value bi_to_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    return v_str_take(value_to_cstring(args[0]));
}
static Value bi_words(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    const char *s = SA(0);
    Value r = v_arr_new();
    const char *p = s;
    while (*p) {
        while (*p && isspace((unsigned char)*p)) p++;
        const char *start = p;
        while (*p && !isspace((unsigned char)*p)) p++;
        if (p > start) { int n = (int)(p - start); char *buf = (char*)malloc(n+1); memcpy(buf,start,n); buf[n]=0; arr_push(r.obj, v_str_take(buf)); }
    }
    return r;
}
static Value bi_lines(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    Value fake[2]; fake[0] = args[0]; fake[1] = v_str("\n");
    return bi_split(fake, 2, err, errmsg);
}
static Value bi_equals_ignore_case(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    const char *a = SA(0), *b = SA(1);
    while (*a && *b) { if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return v_bool(0); a++; b++; }
    return v_bool(*a == 0 && *b == 0);
}
static Value bi_left(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str(""); return v_str_take(dup_range(SA(0), 0, (int)NA(1)));
}
static Value bi_right(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int n = (int)NA(1), len = (int)strlen(s);
    int start = len - n; if (start < 0) start = 0;
    return v_str_take(dup_range(s, start, len));
}
static Value bi_center(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *s = SA(0); int width = (int)NA(1);
    char padc = HAS(2) ? SA(2)[0] : ' ';
    int slen = (int)strlen(s);
    if (slen >= width) return v_str(s);
    int total = width - slen, leftp = total / 2, rightp = total - leftp;
    char *out = (char*)malloc(width + 1);
    memset(out, padc, leftp);
    memcpy(out + leftp, s, slen);
    memset(out + leftp + slen, padc, rightp);
    out[width] = 0;
    return v_str_take(out);
}
static Value bi_string_compare(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0);
    return v_num(strcmp(SA(0), SA(1)));
}
static Value bi_slugify(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) + 1);
    int j = 0; int lastdash = 0;
    for (const char *p = s; *p; p++) {
        if (isalnum((unsigned char)*p)) { out[j++] = tolower((unsigned char)*p); lastdash = 0; }
        else if (!lastdash && j > 0) { out[j++] = '-'; lastdash = 1; }
    }
    while (j > 0 && out[j-1] == '-') j--;
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_url_encode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) * 3 + 1);
    int j = 0;
    for (const char *p = s; *p; p++) {
        unsigned char c = (unsigned char)*p;
        if (isalnum(c) || c=='-'||c=='_'||c=='.'||c=='~') out[j++] = c;
        else j += sprintf(out + j, "%%%02X", c);
    }
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_url_decode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) + 1);
    int j = 0;
    for (const char *p = s; *p; ) {
        if (*p == '%' && isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2])) {
            char hex[3] = { p[1], p[2], 0 };
            out[j++] = (char)strtol(hex, NULL, 16);
            p += 3;
        } else if (*p == '+') { out[j++] = ' '; p++; }
        else out[j++] = *p++;
    }
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_escape_html(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) * 6 + 1);
    int j = 0;
    for (const char *p = s; *p; p++) {
        if (*p == '<') j += sprintf(out+j, "&lt;");
        else if (*p == '>') j += sprintf(out+j, "&gt;");
        else if (*p == '&') j += sprintf(out+j, "&amp;");
        else if (*p == '"') j += sprintf(out+j, "&quot;");
        else out[j++] = *p;
    }
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_unescape_html(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) + 1);
    int j = 0;
    for (const char *p = s; *p; ) {
        if (!strncmp(p, "&lt;", 4)) { out[j++]='<'; p+=4; }
        else if (!strncmp(p, "&gt;", 4)) { out[j++]='>'; p+=4; }
        else if (!strncmp(p, "&amp;", 5)) { out[j++]='&'; p+=5; }
        else if (!strncmp(p, "&quot;", 6)) { out[j++]='"'; p+=6; }
        else out[j++] = *p++;
    }
    out[j] = 0;
    return v_str_take(out);
}
static Value bi_camel_case(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0);
    char *out = (char*)malloc(strlen(s) + 1);
    int j = 0, up = 0, first = 1;
    for (const char *p = s; *p; p++) {
        if (*p == '_' || *p == '-' || isspace((unsigned char)*p)) { up = 1; continue; }
        out[j++] = up && !first ? toupper((unsigned char)*p) : (first ? tolower((unsigned char)*p) : *p);
        up = 0; first = 0;
    }
    out[j] = 0;
    return v_str_take(out);
}
static char *case_join(const char *s, char sep, int upper_all) {
    char *out = (char*)malloc(strlen(s) * 2 + 1);
    int j = 0;
    for (int i = 0; s[i]; i++) {
        char c = s[i];
        if (c == ' ' || c == '-' || c == '_') {
            if (j > 0 && out[j-1] != sep) out[j++] = sep;
            continue;
        }
        if (isupper((unsigned char)c) && i > 0 && out[j-1] != sep) out[j++] = sep;
        out[j++] = upper_all ? toupper((unsigned char)c) : tolower((unsigned char)c);
    }
    out[j] = 0;
    return out;
}
static Value bi_snake_case(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(""); return v_str_take(case_join(SA(0), '_', 0));
}
static Value bi_kebab_case(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(""); return v_str_take(case_join(SA(0), '-', 0));
}
static Value bi_count_words(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    Value w = bi_words(args, argc, err, errmsg);
    return v_num(w.obj->arr.count);
}
static Value bi_count_lines(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    const char *s = SA(0); int n = 1;
    for (const char *p = s; *p; p++) if (*p == '\n') n++;
    return v_num(n);
}
static Value bi_is_palindrome(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    const char *s = SA(0); int a = 0, b = (int)strlen(s) - 1;
    while (a < b) {
        while (a < b && !isalnum((unsigned char)s[a])) a++;
        while (a < b && !isalnum((unsigned char)s[b])) b--;
        if (tolower((unsigned char)s[a]) != tolower((unsigned char)s[b])) return v_bool(0);
        a++; b--;
    }
    return v_bool(1);
}

/* ========================= ORTAK (polimorfik) ========================= */

static Value bi_len(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    Value v = args[0];
    if (v.type == T_STR) return v_num(v.obj->str.len);
    if (v.type == T_ARR) return v_num(v.obj->arr.count);
    if (v.type == T_MAP) return v_num(v.obj->map.count);
    return v_num(0);
}
static Value bi_first(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    if (args[0].type == T_ARR) return args[0].obj->arr.count ? args[0].obj->arr.items[0] : v_null();
    if (args[0].type == T_STR) return args[0].obj->str.len ? bi_char_at(args, 2, err, errmsg) : v_str("");
    return v_null();
}
static Value bi_last(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    if (args[0].type == T_ARR) return args[0].obj->arr.count ? args[0].obj->arr.items[args[0].obj->arr.count-1] : v_null();
    if (args[0].type == T_STR) {
        int n = args[0].obj->str.len; if (!n) return v_str("");
        char buf[2] = { args[0].obj->str.chars[n-1], 0 }; return v_str(buf);
    }
    return v_null();
}
static Value bi_slice(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    Value v = args[0];
    int len = v.type == T_ARR ? v.obj->arr.count : (v.type == T_STR ? v.obj->str.len : 0);
    int start = HAS(1) ? (int)NA(1) : 0;
    int end = HAS(2) ? (int)NA(2) : len;
    if (start < 0) start += len; if (end < 0) end += len;
    if (start < 0) start = 0; if (end > len) end = len; if (start > end) start = end;
    if (v.type == T_STR) return v_str_take(dup_range(v.obj->str.chars, start, end));
    if (v.type == T_ARR) {
        Value r = v_arr_new();
        for (int i = start; i < end; i++) arr_push(r.obj, v.obj->arr.items[i]);
        return r;
    }
    return v_null();
}
static Value bi_copy(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    Value v = args[0];
    if (v.type == T_ARR) { Value r = v_arr_new(); for (int i=0;i<v.obj->arr.count;i++) arr_push(r.obj, v.obj->arr.items[i]); return r; }
    if (v.type == T_MAP) { Value r = v_map_new(); for (int i=0;i<v.obj->map.count;i++) map_set(r.obj, v.obj->map.entries[i].key, *(v.obj->map.entries[i].val)); return r; }
    return v;
}

/* ========================= DIZI (array) ========================= */

static Value bi_push(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_null();
    for (int i = 1; i < argc; i++) arr_push(args[0].obj, args[i]);
    return args[0];
}
static Value bi_pop(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count == 0) return v_null();
    return args[0].obj->arr.items[--args[0].obj->arr.count];
}
static Value bi_shift(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count == 0) return v_null();
    Value first = args[0].obj->arr.items[0];
    for (int i = 1; i < args[0].obj->arr.count; i++) args[0].obj->arr.items[i-1] = args[0].obj->arr.items[i];
    args[0].obj->arr.count--;
    return first;
}
static Value bi_unshift(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_null();
    Obj *o = args[0].obj;
    arr_push(o, v_null());
    for (int i = o->arr.count - 1; i > 0; i--) o->arr.items[i] = o->arr.items[i-1];
    o->arr.items[0] = args[1];
    return args[0];
}
static Value bi_get(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_null();
    if (args[0].type == T_ARR) return arr_get(args[0].obj, (int)NA(1));
    if (args[0].type == T_MAP) { Value *r = map_get(args[0].obj, SA(1)); return r ? *r : v_null(); }
    return v_null();
}
static Value bi_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_null();
    if (args[0].type == T_ARR) {
        int i = (int)NA(1); Obj *o = args[0].obj;
        if (i < 0) i += o->arr.count;
        while (i >= o->arr.count) arr_push(o, v_null());
        if (i >= 0 && i < o->arr.count) o->arr.items[i] = args[2];
    } else if (args[0].type == T_MAP) map_set(args[0].obj, SA(1), args[2]);
    return args[0];
}
static Value bi_splice(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_arr_new();
    Obj *o = args[0].obj;
    int start = (int)NA(1); if (start < 0) start += o->arr.count;
    if (start < 0) start = 0; if (start > o->arr.count) start = o->arr.count;
    int delcount = HAS(2) ? (int)NA(2) : o->arr.count - start;
    if (delcount < 0) delcount = 0; if (start + delcount > o->arr.count) delcount = o->arr.count - start;
    Value removed = v_arr_new();
    for (int i = 0; i < delcount; i++) arr_push(removed.obj, o->arr.items[start+i]);
    int ninsert = argc > 3 ? argc - 3 : 0;
    int newcount = o->arr.count - delcount + ninsert;
    Value *newitems = (Value*)malloc(sizeof(Value) * (newcount > 0 ? newcount : 1));
    int j = 0;
    for (int i = 0; i < start; i++) newitems[j++] = o->arr.items[i];
    for (int i = 0; i < ninsert; i++) newitems[j++] = args[3+i];
    for (int i = start + delcount; i < o->arr.count; i++) newitems[j++] = o->arr.items[i];
    free(o->arr.items);
    o->arr.items = newitems; o->arr.count = newcount; o->arr.cap = newcount > 0 ? newcount : 1;
    return removed;
}
static void insertion_sort(Obj *o, Value cmp, int has_cmp, int desc) {
    for (int i = 1; i < o->arr.count; i++) {
        Value key = o->arr.items[i];
        int j = i - 1;
        for (;;) {
            if (j < 0) break;
            int goesBefore;
            if (has_cmp) {
                Value cargs[2] = { o->arr.items[j], key };
                Value r = interp_call_value(cmp, cargs, 2);
                goesBefore = value_num(r) > 0;
            } else {
                goesBefore = desc ? value_less(o->arr.items[j], key) : value_less(key, o->arr.items[j]);
            }
            if (!goesBefore) break;
            o->arr.items[j+1] = o->arr.items[j];
            j--;
        }
        o->arr.items[j+1] = key;
    }
}
static Value bi_sort(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return args[0];
    int has_cmp = argc >= 2 && (args[1].type == T_FUNC || args[1].type == T_NATIVE);
    insertion_sort(args[0].obj, has_cmp ? args[1] : v_null(), has_cmp, 0);
    return args[0];
}
static Value bi_sort_desc(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return args[0];
    insertion_sort(args[0].obj, v_null(), 0, 1);
    return args[0];
}
static Value bi_map(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        arr_push(r.obj, interp_call_value(args[1], cargs, 2));
    }
    return r;
}
static Value bi_filter(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) arr_push(r.obj, args[0].obj->arr.items[i]);
    }
    return r;
}
static Value bi_reduce(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_null();
    Value acc = HAS(2) ? args[2] : (args[0].obj->arr.count ? args[0].obj->arr.items[0] : v_null());
    int start = HAS(2) ? 0 : 1;
    for (int i = start; i < args[0].obj->arr.count; i++) {
        Value cargs[3] = { acc, args[0].obj->arr.items[i], v_num(i) };
        acc = interp_call_value(args[1], cargs, 3);
    }
    return acc;
}
static Value bi_find(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_null();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) return args[0].obj->arr.items[i];
    }
    return v_null();
}
static Value bi_find_index(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_num(-1);
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) return v_num(i);
    }
    return v_num(-1);
}
static Value bi_some(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_bool(0);
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) return v_bool(1);
    }
    return v_bool(0);
}
static Value bi_every(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_bool(1);
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (!is_truthy(interp_call_value(args[1], cargs, 2))) return v_bool(0);
    }
    return v_bool(1);
}
static void flatten_rec(Obj *src, Obj *dst, int deep) {
    for (int i = 0; i < src->arr.count; i++) {
        Value it = src->arr.items[i];
        if (it.type == T_ARR && deep) flatten_rec(it.obj, dst, deep);
        else if (it.type == T_ARR && !deep) { for (int j=0;j<it.obj->arr.count;j++) arr_push(dst, it.obj->arr.items[j]); }
        else arr_push(dst, it);
    }
}
static Value bi_flatten(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new(); flatten_rec(args[0].obj, r.obj, 0); return r;
}
static Value bi_flatten_deep(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new(); flatten_rec(args[0].obj, r.obj, 1); return r;
}
static Value bi_unique(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value it = args[0].obj->arr.items[i];
        int dup = 0;
        for (int j = 0; j < r.obj->arr.count; j++) if (values_equal(r.obj->arr.items[j], it)) { dup = 1; break; }
        if (!dup) arr_push(r.obj, it);
    }
    return r;
}
static Value bi_fill(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_arr_new();
    int n = (int)NA(0);
    Value r = v_arr_new();
    for (int i = 0; i < n; i++) arr_push(r.obj, args[1]);
    return r;
}
static Value bi_range(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    double start = 0, end = NA(0), step = 1;
    if (argc >= 2) { start = NA(0); end = NA(1); }
    if (argc >= 3) step = NA(2);
    if (step == 0) step = 1;
    Value r = v_arr_new();
    if (step > 0) for (double x = start; x < end; x += step) arr_push(r.obj, v_num(x));
    else for (double x = start; x > end; x += step) arr_push(r.obj, v_num(x));
    return r;
}
static Value bi_sum(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_num(0);
    double s = 0; for (int i=0;i<args[0].obj->arr.count;i++) s += value_num(args[0].obj->arr.items[i]);
    return v_num(s);
}
static Value bi_avg(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(0);
    double s = 0; for (int i=0;i<args[0].obj->arr.count;i++) s += value_num(args[0].obj->arr.items[i]);
    return v_num(s / args[0].obj->arr.count);
}
static Value bi_arr_min(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_null();
    double m = value_num(args[0].obj->arr.items[0]);
    for (int i=1;i<args[0].obj->arr.count;i++) { double v = value_num(args[0].obj->arr.items[i]); if (v<m) m=v; }
    return v_num(m);
}
static Value bi_arr_max(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_null();
    double m = value_num(args[0].obj->arr.items[0]);
    for (int i=1;i<args[0].obj->arr.count;i++) { double v = value_num(args[0].obj->arr.items[i]); if (v>m) m=v; }
    return v_num(m);
}
static Value bi_clear(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    if (args[0].type == T_ARR) args[0].obj->arr.count = 0;
    if (args[0].type == T_MAP) args[0].obj->map.count = 0;
    return v_null();
}
static Value bi_insert(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3 || args[0].type != T_ARR) return args[0];
    Obj *o = args[0].obj; int i = (int)NA(1); if (i<0) i+=o->arr.count; if (i<0) i=0; if (i>o->arr.count) i=o->arr.count;
    arr_push(o, v_null());
    for (int k = o->arr.count-1; k > i; k--) o->arr.items[k] = o->arr.items[k-1];
    o->arr.items[i] = args[2];
    return args[0];
}
static Value bi_remove_at(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_null();
    Obj *o = args[0].obj; int i = (int)NA(1); if (i<0) i+=o->arr.count;
    if (i<0 || i>=o->arr.count) return v_null();
    Value removed = o->arr.items[i];
    for (int k = i; k < o->arr.count-1; k++) o->arr.items[k] = o->arr.items[k+1];
    o->arr.count--;
    return removed;
}
static Value bi_swap(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3 || args[0].type != T_ARR) return v_null();
    Obj *o = args[0].obj; int i = (int)NA(1), j = (int)NA(2);
    if (i>=0 && i<o->arr.count && j>=0 && j<o->arr.count) { Value t = o->arr.items[i]; o->arr.items[i]=o->arr.items[j]; o->arr.items[j]=t; }
    return args[0];
}
static Value bi_shuffle(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return args[0];
    Obj *o = args[0].obj;
    for (int i = o->arr.count - 1; i > 0; i--) {
        int j = (int)(xorshift() % (unsigned long)(i + 1));
        Value t = o->arr.items[i]; o->arr.items[i] = o->arr.items[j]; o->arr.items[j] = t;
    }
    return args[0];
}
static Value bi_count_if(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_num(0);
    int c = 0;
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) c++;
    }
    return v_num(c);
}
static Value bi_array_new(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_arr_new();
}
static Value bi_zip(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR || args[1].type != T_ARR) return v_arr_new();
    Value r = v_arr_new();
    int n = args[0].obj->arr.count < args[1].obj->arr.count ? args[0].obj->arr.count : args[1].obj->arr.count;
    for (int i = 0; i < n; i++) {
        Value pair = v_arr_new();
        arr_push(pair.obj, args[0].obj->arr.items[i]);
        arr_push(pair.obj, args[1].obj->arr.items[i]);
        arr_push(r.obj, pair);
    }
    return r;
}
static Value bi_chunk(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_arr_new();
    int size = (int)NA(1); if (size < 1) size = 1;
    Value r = v_arr_new();
    Obj *o = args[0].obj;
    for (int i = 0; i < o->arr.count; i += size) {
        Value part = v_arr_new();
        for (int j = i; j < i + size && j < o->arr.count; j++) arr_push(part.obj, o->arr.items[j]);
        arr_push(r.obj, part);
    }
    return r;
}
static Value bi_rotate_left(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Obj *o = args[0].obj; int n = o->arr.count; if (n==0) return v_arr_new();
    int k = HAS(1) ? ((int)NA(1)) % n : 1; if (k < 0) k += n;
    Value r = v_arr_new();
    for (int i = 0; i < n; i++) arr_push(r.obj, o->arr.items[(i + k) % n]);
    return r;
}
static Value bi_rotate_right(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Obj *o = args[0].obj; int n = o->arr.count; if (n==0) return v_arr_new();
    int k = HAS(1) ? ((int)NA(1)) % n : 1; if (k < 0) k += n;
    Value r = v_arr_new();
    for (int i = 0; i < n; i++) arr_push(r.obj, o->arr.items[((i - k) % n + n) % n]);
    return r;
}
static Value bi_partition(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_arr_new();
    Value yes = v_arr_new(), no = v_arr_new();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value cargs[2] = { args[0].obj->arr.items[i], v_num(i) };
        if (is_truthy(interp_call_value(args[1], cargs, 2))) arr_push(yes.obj, args[0].obj->arr.items[i]);
        else arr_push(no.obj, args[0].obj->arr.items[i]);
    }
    Value r = v_arr_new(); arr_push(r.obj, yes); arr_push(r.obj, no);
    return r;
}
static Value bi_group_by(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR) return v_map_new();
    Value r = v_map_new();
    for (int i = 0; i < args[0].obj->arr.count; i++) {
        Value item = args[0].obj->arr.items[i];
        Value cargs[2] = { item, v_num(i) };
        Value key = interp_call_value(args[1], cargs, 2);
        char *ks = value_to_cstring(key);
        Value *existing = map_get(r.obj, ks);
        if (existing) arr_push(existing->obj, item);
        else { Value arr = v_arr_new(); arr_push(arr.obj, item); map_set(r.obj, ks, arr); }
        free(ks);
    }
    return r;
}
static Value bi_array_equals(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    return v_bool(deep_equals_value(args[0], args[1]));
}
static Value bi_array_min_index(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(-1);
    int bi = 0; double bv = value_num(args[0].obj->arr.items[0]);
    for (int i=1;i<args[0].obj->arr.count;i++) { double v=value_num(args[0].obj->arr.items[i]); if (v<bv){bv=v;bi=i;} }
    return v_num(bi);
}
static Value bi_array_max_index(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(-1);
    int bi = 0; double bv = value_num(args[0].obj->arr.items[0]);
    for (int i=1;i<args[0].obj->arr.count;i++) { double v=value_num(args[0].obj->arr.items[i]); if (v>bv){bv=v;bi=i;} }
    return v_num(bi);
}
static Value bi_array_sum_squares(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_num(0);
    double s = 0; for (int i=0;i<args[0].obj->arr.count;i++) { double v = value_num(args[0].obj->arr.items[i]); s += v*v; }
    return v_num(s);
}

/* ========================= HARITA (map) ========================= */

static Value bi_map_new(Value *args, int argc, int *err, char *errmsg) { (void)args;(void)argc; OK return v_map_new(); }
static Value bi_map_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3 || args[0].type != T_MAP) return v_null();
    char *ks = value_to_cstring(args[1]); map_set(args[0].obj, ks, args[2]); free(ks);
    return args[0];
}
static Value bi_map_get(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_MAP) return v_null();
    char *ks = value_to_cstring(args[1]); Value *r = map_get(args[0].obj, ks); free(ks);
    return r ? *r : v_null();
}
static Value bi_map_has(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_MAP) return v_bool(0);
    char *ks = value_to_cstring(args[1]); Value *r = map_get(args[0].obj, ks); free(ks);
    return v_bool(r != NULL);
}
static Value bi_map_delete(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_MAP) return v_bool(0);
    char *ks = value_to_cstring(args[1]);
    Obj *o = args[0].obj;
    for (int i = 0; i < o->map.count; i++) {
        if (strcmp(o->map.entries[i].key, ks) == 0) {
            free(o->map.entries[i].key); free(o->map.entries[i].val);
            for (int j = i; j < o->map.count - 1; j++) o->map.entries[j] = o->map.entries[j+1];
            o->map.count--;
            free(ks);
            return v_bool(1);
        }
    }
    free(ks);
    return v_bool(0);
}
static Value bi_map_keys(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_MAP) return v_arr_new();
    Value r = v_arr_new();
    for (int i = 0; i < args[0].obj->map.count; i++) arr_push(r.obj, v_str(args[0].obj->map.entries[i].key));
    return r;
}
static Value bi_map_values(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_MAP) return v_arr_new();
    Value r = v_arr_new();
    for (int i = 0; i < args[0].obj->map.count; i++) arr_push(r.obj, *(args[0].obj->map.entries[i].val));
    return r;
}
static Value bi_map_size(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_MAP) return v_num(0);
    return v_num(args[0].obj->map.count);
}
static Value bi_map_clear(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_MAP) return v_null();
    args[0].obj->map.count = 0; return v_null();
}
static Value bi_map_merge(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_map_new();
    Value r = v_map_new();
    if (args[0].type == T_MAP) for (int i=0;i<args[0].obj->map.count;i++) map_set(r.obj, args[0].obj->map.entries[i].key, *(args[0].obj->map.entries[i].val));
    if (args[1].type == T_MAP) for (int i=0;i<args[1].obj->map.count;i++) map_set(r.obj, args[1].obj->map.entries[i].key, *(args[1].obj->map.entries[i].val));
    return r;
}
static Value bi_map_copy(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_MAP) return v_map_new();
    Value r = v_map_new();
    for (int i=0;i<args[0].obj->map.count;i++) map_set(r.obj, args[0].obj->map.entries[i].key, *(args[0].obj->map.entries[i].val));
    return r;
}
static Value bi_map_to_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("{}");
    return v_str_take(value_to_cstring(args[0]));
}
static Value bi_map_each(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_MAP) return v_null();
    for (int i = 0; i < args[0].obj->map.count; i++) {
        Value cargs[2] = { v_str(args[0].obj->map.entries[i].key), *(args[0].obj->map.entries[i].val) };
        interp_call_value(args[1], cargs, 2);
    }
    return v_null();
}
static Value bi_char_frequency(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_map_new();
    Value r = v_map_new();
    for (const char *p = SA(0); *p; p++) {
        char key[2] = { *p, 0 };
        Value *existing = map_get(r.obj, key);
        if (existing) existing->num += 1;
        else map_set(r.obj, key, v_num(1));
    }
    return r;
}

/* ========================= G/C - DOSYA / SISTEM ========================= */

static Value bi_print(Value *args, int argc, int *err, char *errmsg) {
    OK for (int i=0;i<argc;i++) { if (i) fputc(' ', stdout); value_print(args[i], 0); }
    fflush(stdout);
    return v_null();
}
static Value bi_println(Value *args, int argc, int *err, char *errmsg) {
    OK for (int i=0;i<argc;i++) { if (i) fputc(' ', stdout); value_print(args[i], 0); }
    fputc('\n', stdout);
    return v_null();
}
static Value bi_input(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc >= 1) { value_print(args[0], 0); fflush(stdout); }
    char buf[4096];
    if (!fgets(buf, sizeof(buf), stdin)) return v_str("");
    size_t n = strlen(buf);
    while (n > 0 && (buf[n-1] == '\n' || buf[n-1] == '\r')) buf[--n] = 0;
    return v_str(buf);
}
static Value bi_sistem(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    return popen_capture(SA(0));
}
static Value bi_file_read(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    int ok; Value r = read_whole_file(SA(0), &ok);
    return ok ? r : v_null();
}
static Value bi_file_write(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    FILE *f = fopen(SA(0), "wb"); if (!f) return v_bool(0);
    fputs(SA(1), f); fclose(f); return v_bool(1);
}
static Value bi_file_append(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    FILE *f = fopen(SA(0), "ab"); if (!f) return v_bool(0);
    fputs(SA(1), f); fclose(f); return v_bool(1);
}
static Value bi_file_append_line(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    FILE *f = fopen(SA(0), "ab"); if (!f) return v_bool(0);
    fputs(SA(1), f); fputc('\n', f); fclose(f); return v_bool(1);
}
static Value bi_file_exists(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(access(SA(0), F_OK) == 0);
}
static Value bi_file_delete(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(remove(SA(0)) == 0);
}
static Value bi_file_size(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(-1);
    struct stat st; if (stat(SA(0), &st) != 0) return v_num(-1);
    return v_num((double)st.st_size);
}
static Value bi_file_copy(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    int ok; Value content = read_whole_file(SA(0), &ok);
    if (!ok) return v_bool(0);
    FILE *f = fopen(SA(1), "wb"); if (!f) return v_bool(0);
    fwrite(content.obj->str.chars, 1, content.obj->str.len, f);
    fclose(f);
    return v_bool(1);
}
static Value bi_file_rename(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0); return v_bool(rename(SA(0), SA(1)) == 0);
}
static Value bi_dir_list(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    DIR *d = opendir(SA(0));
    Value r = v_arr_new();
    if (!d) return r;
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) continue;
        arr_push(r.obj, v_str(ent->d_name));
    }
    closedir(d);
    return r;
}
static Value bi_dir_create(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(mkdir(SA(0), 0755) == 0);
}
static Value bi_dir_exists(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    struct stat st; if (stat(SA(0), &st) != 0) return v_bool(0);
    return v_bool(S_ISDIR(st.st_mode));
}
static Value bi_is_directory(Value *args, int argc, int *err, char *errmsg) { return bi_dir_exists(args, argc, err, errmsg); }
static Value bi_is_file(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    struct stat st; if (stat(SA(0), &st) != 0) return v_bool(0);
    return v_bool(S_ISREG(st.st_mode));
}
static Value bi_env_get(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    const char *v = getenv(SA(0));
    return v ? v_str(v) : v_null();
}
static Value bi_env_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    return v_bool(setenv(SA(0), SA(1), 1) == 0);
}
static Value bi_exit(Value *args, int argc, int *err, char *errmsg) {
    OK int code = argc >= 1 ? (int)NA(0) : 0;
    exit(code);
    return v_null();
}
static Value bi_sleep_ms(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    struct timespec ts; double ms = NA(0);
    ts.tv_sec = (time_t)(ms / 1000);
    ts.tv_nsec = (long)(fmod(ms, 1000) * 1000000);
    nanosleep(&ts, NULL);
    return v_null();
}
static Value bi_time_now(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_num((double)time(NULL));
}
static Value bi_clock_ms(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return v_num((double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1000000.0);
}
static Value bi_date_string(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    time_t t = time(NULL); char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", localtime(&t));
    return v_str(buf);
}
static Value bi_format_time(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    time_t t = (time_t)NA(0);
    char buf[128];
    strftime(buf, sizeof(buf), SA(1), localtime(&t));
    return v_str(buf);
}
static Value bi_current_dir(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    char buf[1024];
    if (!getcwd(buf, sizeof(buf))) return v_str("");
    return v_str(buf);
}
static Value bi_path_join(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("");
    const char *a = SA(0), *b = SA(1);
    int alen = (int)strlen(a);
    char *out = (char*)malloc(alen + strlen(b) + 2);
    strcpy(out, a);
    if (alen > 0 && a[alen-1] != '/') strcat(out, "/");
    strcat(out, b);
    return v_str_take(out);
}
static Value bi_path_basename(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0); const char *p = strrchr(s, '/');
    return v_str(p ? p + 1 : s);
}
static Value bi_path_dirname(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str(".");
    const char *s = SA(0); const char *p = strrchr(s, '/');
    if (!p) return v_str(".");
    int n = (int)(p - s); if (n == 0) n = 1;
    char *out = (char*)malloc(n + 1); memcpy(out, s, n); out[n] = 0;
    return v_str_take(out);
}
static Value bi_path_extension(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0); const char *p = strrchr(s, '.');
    return v_str(p ? p + 1 : "");
}
static Value bi_cpu_count(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    return v_num(n > 0 ? (double)n : 1);
}
static Value bi_file_lines(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    int ok; Value content = read_whole_file(SA(0), &ok);
    if (!ok) return v_arr_new();
    Value fake[2] = { content, v_str("\n") };
    return bi_split(fake, 2, err, errmsg);
}
static Value bi_list_env_vars(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    Value r = v_arr_new();
    for (char **e = environ; *e; e++) arr_push(r.obj, v_str(*e));
    return r;
}
static Value bi_ping_host(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "ping -c 1 -W 2 \"%s\" > /dev/null 2>&1", SA(0));
    return v_bool(system(cmd) == 0);
}
static Value bi_download_file(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "curl -sL -o \"%s\" \"%s\" 2>/dev/null || wget -q -O \"%s\" \"%s\" 2>/dev/null", SA(1), SA(0), SA(1), SA(0));
    return v_bool(system(cmd) == 0);
}
static Value bi_http_get(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "curl -sL \"%s\" 2>/dev/null", SA(0));
    return popen_capture(cmd);
}

/* ========================= TUR / DONUSUM ========================= */

static Value bi_typeof(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("null"); return v_str(type_name(args[0]));
}
#define TYPE_CHECK(nm, tt) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    OK if (argc < 1) return v_bool(0); return v_bool(args[0].type == tt); \
}
TYPE_CHECK(is_null, T_NULL) TYPE_CHECK(is_bool, T_BOOL) TYPE_CHECK(is_num, T_NUM)
TYPE_CHECK(is_str, T_STR) TYPE_CHECK(is_array, T_ARR) TYPE_CHECK(is_map, T_MAP)
TYPE_CHECK(is_func, T_FUNC) TYPE_CHECK(is_native, T_NATIVE)

static Value bi_to_bool(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0); return v_bool(is_truthy(args[0]));
}
static Value bi_to_num(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(value_num(args[0]));
}
static Value bi_clone(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null(); return deep_copy_value(args[0]);
}
static Value bi_deep_equals(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0); return v_bool(deep_equals_value(args[0], args[1]));
}
static Value bi_assert(Value *args, int argc, int *err, char *errmsg) {
    if (argc < 1 || !is_truthy(args[0])) {
        *err = 1;
        snprintf(errmsg, 256, "%s", argc >= 2 ? SA(1) : "assert basarisiz");
        return v_null();
    }
    return v_null();
}

/* ========================= BIT ISLEMLERI ========================= */

#define BIT2(nm, expr) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    OK if (argc < 2) return v_num(0); \
    long long a = (long long)NA(0), b = (long long)NA(1); \
    return v_num((double)(expr)); \
}
BIT2(band, (a & b)) BIT2(bor, (a | b)) BIT2(bxor, (a ^ b))
BIT2(bshl, (a << b)) BIT2(bshr, (a >> b))
static Value bi_bnot(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num((double)(~(long long)NA(0)));
}
static Value bi_bit_count(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    unsigned long long x = (unsigned long long)NA(0); int c = 0;
    while (x) { c += x & 1; x >>= 1; }
    return v_num(c);
}

/* ========================= JSON ========================= */

static Value bi_json_encode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("null"); return v_str_take(value_to_cstring(args[0]));
}
static const char *json_skip_ws(const char *p) { while (*p==' '||*p=='\t'||*p=='\n'||*p=='\r') p++; return p; }
static const char *json_parse_value(const char *p, Value *out);
static const char *json_parse_string_raw(const char *p, char **out) {
    p++; /* skip opening quote */
    size_t cap = 64, len = 0; char *buf = (char*)malloc(cap);
    while (*p && *p != '"') {
        char c = *p++;
        if (c == '\\' && *p) {
            char e = *p++;
            switch (e) { case 'n': c='\n'; break; case 't': c='\t'; break; case 'r': c='\r'; break;
                case '"': c='"'; break; case '\\': c='\\'; break; case '/': c='/'; break; default: c = e; }
        }
        if (len + 1 >= cap) { cap *= 2; buf = (char*)realloc(buf, cap); }
        buf[len++] = c;
    }
    if (*p == '"') p++;
    buf[len] = 0; *out = buf;
    return p;
}
static const char *json_parse_value(const char *p, Value *out) {
    p = json_skip_ws(p);
    if (*p == '"') { char *s; p = json_parse_string_raw(p, &s); *out = v_str_take(s); return p; }
    if (*p == '{') {
        p++; Value m = v_map_new();
        p = json_skip_ws(p);
        if (*p == '}') { p++; *out = m; return p; }
        for (;;) {
            p = json_skip_ws(p);
            char *key; p = json_parse_string_raw(p, &key);
            p = json_skip_ws(p);
            if (*p == ':') p++;
            Value val; p = json_parse_value(p, &val);
            map_set(m.obj, key, val);
            free(key);
            p = json_skip_ws(p);
            if (*p == ',') { p++; continue; }
            if (*p == '}') { p++; break; }
            break;
        }
        *out = m; return p;
    }
    if (*p == '[') {
        p++; Value a = v_arr_new();
        p = json_skip_ws(p);
        if (*p == ']') { p++; *out = a; return p; }
        for (;;) {
            Value val; p = json_parse_value(p, &val);
            arr_push(a.obj, val);
            p = json_skip_ws(p);
            if (*p == ',') { p++; continue; }
            if (*p == ']') { p++; break; }
            break;
        }
        *out = a; return p;
    }
    if (!strncmp(p, "true", 4)) { *out = v_bool(1); return p + 4; }
    if (!strncmp(p, "false", 5)) { *out = v_bool(0); return p + 5; }
    if (!strncmp(p, "null", 4)) { *out = v_null(); return p + 4; }
    char *endp; double d = strtod(p, &endp);
    *out = v_num(d);
    return endp;
}
static Value bi_json_decode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    Value out; json_parse_value(SA(0), &out);
    return out;
}

/* ========================= HASH / KODLAMA ========================= */

static const char b64tbl[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static Value bi_base64_encode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const unsigned char *s = (const unsigned char*)SA(0);
    int len = (int)strlen((const char*)s);
    char *out = (char*)malloc((len + 2) / 3 * 4 + 1);
    int oi = 0, i = 0;
    for (; i + 2 < len; i += 3) {
        unsigned v = (s[i] << 16) | (s[i+1] << 8) | s[i+2];
        out[oi++] = b64tbl[(v >> 18) & 63]; out[oi++] = b64tbl[(v >> 12) & 63];
        out[oi++] = b64tbl[(v >> 6) & 63]; out[oi++] = b64tbl[v & 63];
    }
    int rem = len - i;
    if (rem == 1) {
        unsigned v = s[i] << 16;
        out[oi++] = b64tbl[(v>>18)&63]; out[oi++] = b64tbl[(v>>12)&63]; out[oi++]='='; out[oi++]='=';
    } else if (rem == 2) {
        unsigned v = (s[i] << 16) | (s[i+1] << 8);
        out[oi++] = b64tbl[(v>>18)&63]; out[oi++] = b64tbl[(v>>12)&63]; out[oi++] = b64tbl[(v>>6)&63]; out[oi++]='=';
    }
    out[oi] = 0;
    return v_str_take(out);
}
static int b64val(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62; if (c == '/') return 63;
    return -1;
}
static Value bi_base64_decode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    const char *s = SA(0); int len = (int)strlen(s);
    char *out = (char*)malloc(len + 1); int oi = 0;
    int vals[4], vi = 0;
    for (int i = 0; i < len; i++) {
        int v = b64val(s[i]);
        if (v < 0) continue;
        vals[vi++] = v;
        if (vi == 4) {
            out[oi++] = (vals[0] << 2) | (vals[1] >> 4);
            out[oi++] = (vals[1] << 4) | (vals[2] >> 2);
            out[oi++] = (vals[2] << 6) | vals[3];
            vi = 0;
        }
    }
    if (vi == 3) { out[oi++] = (vals[0]<<2)|(vals[1]>>4); out[oi++] = (vals[1]<<4)|(vals[2]>>2); }
    else if (vi == 2) { out[oi++] = (vals[0]<<2)|(vals[1]>>4); }
    out[oi] = 0;
    return v_str_take(out);
}
static Value bi_hash_string(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    unsigned long h = 5381;
    for (const char *p = SA(0); *p; p++) h = ((h << 5) + h) + (unsigned char)*p;
    return v_num((double)(h & 0x7fffffffUL));
}
static Value bi_checksum(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    unsigned long s = 0;
    for (const char *p = SA(0); *p; p++) s = (s + (unsigned char)*p) % 65536;
    return v_num((double)s);
}
static Value bi_uuid4(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK
    char buf[37];
    const char *hex = "0123456789abcdef";
    int idx = 0;
    for (int i = 0; i < 36; i++) {
        if (i==8||i==13||i==18||i==23) { buf[i] = '-'; continue; }
        if (i==14) { buf[i] = '4'; continue; }
        int r = (int)(xorshift() % 16);
        if (i==19) r = (r & 0x3) | 0x8;
        buf[i] = hex[r];
        idx++;
    }
    buf[36] = 0;
    return v_str(buf);
}

/* ========================= HATA AYIKLAMA / CESITLI ========================= */

static Value bi_debug_print(Value *args, int argc, int *err, char *errmsg) {
    OK for (int i=0;i<argc;i++) { char *s = value_to_cstring(args[i]); fprintf(stderr, "[hata-ayikla] %s\n", s); free(s); }
    return argc ? args[0] : v_null();
}
static Value bi_panic(Value *args, int argc, int *err, char *errmsg) {
    *err = 1;
    snprintf(errmsg, 256, "%s", argc >= 1 ? SA(0) : "panik");
    return v_null();
}
static Value bi_version(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_str("FoxC 1.0");
}
static Value bi_identity(Value *args, int argc, int *err, char *errmsg) {
    OK return argc ? args[0] : v_null();
}
static Value bi_noop(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_null();
}
static Value bi_benchmark_start(Value *args, int argc, int *err, char *errmsg) {
    return bi_clock_ms(args, argc, err, errmsg);
}
static Value bi_benchmark_end(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    double now = (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1000000.0;
    return v_num(now - NA(0));
}
static Value bi_timestamp_diff(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0); return v_num(NA(1) - NA(0));
}

/* ========================= ISTATISTIK ========================= */

static double *arr_doubles(Obj *o, int *n) {
    *n = o->arr.count;
    double *d = (double*)malloc(sizeof(double) * (*n > 0 ? *n : 1));
    for (int i = 0; i < *n; i++) d[i] = value_num(o->arr.items[i]);
    return d;
}
static int cmp_double(const void *a, const void *b) {
    double x = *(const double*)a, y = *(const double*)b;
    return (x > y) - (x < y);
}
static Value bi_median(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(0);
    int n; double *d = arr_doubles(args[0].obj, &n);
    qsort(d, n, sizeof(double), cmp_double);
    double m = (n % 2) ? d[n/2] : (d[n/2-1] + d[n/2]) / 2.0;
    free(d);
    return v_num(m);
}
static Value bi_variance(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(0);
    int n; double *d = arr_doubles(args[0].obj, &n);
    double mean = 0; for (int i=0;i<n;i++) mean += d[i]; mean /= n;
    double var = 0; for (int i=0;i<n;i++) var += (d[i]-mean)*(d[i]-mean); var /= n;
    free(d);
    return v_num(var);
}
static Value bi_stddev(Value *args, int argc, int *err, char *errmsg) {
    Value v = bi_variance(args, argc, err, errmsg);
    return v_num(sqrt(v.num));
}
static Value bi_mode(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_null();
    Obj *o = args[0].obj;
    double best = value_num(o->arr.items[0]); int bestcount = 0;
    for (int i = 0; i < o->arr.count; i++) {
        double v = value_num(o->arr.items[i]);
        int c = 0;
        for (int j = 0; j < o->arr.count; j++) if (value_num(o->arr.items[j]) == v) c++;
        if (c > bestcount) { bestcount = c; best = v; }
    }
    return v_num(best);
}
static Value bi_percentile(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(0);
    int n; double *d = arr_doubles(args[0].obj, &n);
    qsort(d, n, sizeof(double), cmp_double);
    double p = NA(1) / 100.0 * (n - 1);
    int lo = (int)floor(p), hi = (int)ceil(p);
    double r = lo == hi ? d[lo] : d[lo] + (d[hi]-d[lo]) * (p - lo);
    free(d);
    return v_num(r);
}
static Value bi_normalize(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Obj *o = args[0].obj;
    double mn = 1e300, mx = -1e300;
    for (int i=0;i<o->arr.count;i++) { double v = value_num(o->arr.items[i]); if (v<mn) mn=v; if (v>mx) mx=v; }
    Value r = v_arr_new();
    double range = mx - mn; if (range == 0) range = 1;
    for (int i=0;i<o->arr.count;i++) arr_push(r.obj, v_num((value_num(o->arr.items[i]) - mn) / range));
    return r;
}
static Value bi_cumsum(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_arr_new();
    Value r = v_arr_new(); double s = 0;
    for (int i=0;i<args[0].obj->arr.count;i++) { s += value_num(args[0].obj->arr.items[i]); arr_push(r.obj, v_num(s)); }
    return r;
}
static Value bi_product(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR) return v_num(0);
    double p = 1; for (int i=0;i<args[0].obj->arr.count;i++) p *= value_num(args[0].obj->arr.items[i]);
    return v_num(p);
}
static Value bi_range_of(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count==0) return v_num(0);
    double mn = value_num(args[0].obj->arr.items[0]), mx = mn;
    for (int i=1;i<args[0].obj->arr.count;i++) { double v=value_num(args[0].obj->arr.items[i]); if(v<mn)mn=v; if(v>mx)mx=v; }
    return v_num(mx - mn);
}

/* ========================= GEOMETRI ========================= */

static Value bi_distance_2d(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 4) return v_num(0);
    double dx = NA(2)-NA(0), dy = NA(3)-NA(1); return v_num(sqrt(dx*dx+dy*dy));
}
static Value bi_distance_3d(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 6) return v_num(0);
    double dx=NA(3)-NA(0), dy=NA(4)-NA(1), dz=NA(5)-NA(2); return v_num(sqrt(dx*dx+dy*dy+dz*dz));
}
static Value bi_dot_product(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2 || args[0].type != T_ARR || args[1].type != T_ARR) return v_num(0);
    double s = 0; int n = args[0].obj->arr.count < args[1].obj->arr.count ? args[0].obj->arr.count : args[1].obj->arr.count;
    for (int i=0;i<n;i++) s += value_num(args[0].obj->arr.items[i]) * value_num(args[1].obj->arr.items[i]);
    return v_num(s);
}
static Value bi_cross_product_2d(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 4) return v_num(0);
    return v_num(NA(0)*NA(3) - NA(1)*NA(2));
}
static Value bi_magnitude_2d(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(0); return v_num(sqrt(NA(0)*NA(0)+NA(1)*NA(1)));
}
static Value bi_normalize_vector_2d(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_arr_new();
    double x = NA(0), y = NA(1), m = sqrt(x*x+y*y); if (m == 0) m = 1;
    Value r = v_arr_new(); arr_push(r.obj, v_num(x/m)); arr_push(r.obj, v_num(y/m));
    return r;
}
static Value bi_angle_between(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 4) return v_num(0);
    return v_num(atan2(NA(3), NA(2)) - atan2(NA(1), NA(0)));
}
static Value bi_deg_to_compass(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("K");
    static const char *dirs[] = {"K","KD","D","GD","G","GB","B","KB"};
    double d = NA(0); while (d < 0) d += 360; d = fmod(d, 360);
    int idx = (int)((d + 22.5) / 45.0) % 8;
    return v_str(dirs[idx]);
}

/* ========================= RENK ========================= */

static Value bi_rgb_to_hex(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("#000000");
    char buf[8];
    snprintf(buf, sizeof(buf), "#%02x%02x%02x", (int)NA(0) & 255, (int)NA(1) & 255, (int)NA(2) & 255);
    return v_str(buf);
}
static Value bi_hex_to_rgb(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_arr_new();
    const char *s = SA(0); if (*s == '#') s++;
    int r=0,g=0,b=0; sscanf(s, "%02x%02x%02x", &r,&g,&b);
    Value out = v_arr_new(); arr_push(out.obj, v_num(r)); arr_push(out.obj, v_num(g)); arr_push(out.obj, v_num(b));
    return out;
}
static Value bi_rgb_to_hsv(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_arr_new();
    double r=NA(0)/255.0, g=NA(1)/255.0, b=NA(2)/255.0;
    double mx = fmax(r, fmax(g,b)), mn = fmin(r, fmin(g,b)), d = mx - mn;
    double h=0, s = mx==0?0:d/mx, v = mx;
    if (d != 0) {
        if (mx == r) h = fmod((g-b)/d, 6);
        else if (mx == g) h = (b-r)/d + 2;
        else h = (r-g)/d + 4;
        h *= 60; if (h < 0) h += 360;
    }
    Value out = v_arr_new(); arr_push(out.obj, v_num(h)); arr_push(out.obj, v_num(s)); arr_push(out.obj, v_num(v));
    return out;
}
static Value bi_hsv_to_rgb(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_arr_new();
    double h = NA(0), s = NA(1), v = NA(2);
    double c = v*s, x = c*(1-fabs(fmod(h/60.0,2)-1)), m = v-c;
    double r,g,b;
    if (h<60){r=c;g=x;b=0;} else if(h<120){r=x;g=c;b=0;} else if(h<180){r=0;g=c;b=x;}
    else if(h<240){r=0;g=x;b=c;} else if(h<300){r=x;g=0;b=c;} else {r=c;g=0;b=x;}
    Value out = v_arr_new();
    arr_push(out.obj, v_num(round((r+m)*255)));
    arr_push(out.obj, v_num(round((g+m)*255)));
    arr_push(out.obj, v_num(round((b+m)*255)));
    return out;
}
static void hex_to_components(const char *hex, int *r, int *g, int *b) {
    if (*hex == '#') hex++;
    sscanf(hex, "%02x%02x%02x", r, g, b);
}
static Value bi_lighten(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("#000000");
    int r,g,b; hex_to_components(SA(0), &r,&g,&b);
    double amt = NA(1);
    r = (int)fmin(255, r + 255*amt); g = (int)fmin(255, g + 255*amt); b = (int)fmin(255, b + 255*amt);
    char buf[8]; snprintf(buf, sizeof(buf), "#%02x%02x%02x", r,g,b);
    return v_str(buf);
}
static Value bi_darken(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_str("#000000");
    int r,g,b; hex_to_components(SA(0), &r,&g,&b);
    double amt = NA(1);
    r = (int)fmax(0, r - 255*amt); g = (int)fmax(0, g - 255*amt); b = (int)fmax(0, b - 255*amt);
    char buf[8]; snprintf(buf, sizeof(buf), "#%02x%02x%02x", r,g,b);
    return v_str(buf);
}
static Value bi_blend_colors(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 3) return v_str("#000000");
    int r1,g1,b1,r2,g2,b2; hex_to_components(SA(0), &r1,&g1,&b1); hex_to_components(SA(1), &r2,&g2,&b2);
    double t = NA(2);
    int r = (int)(r1 + (r2-r1)*t), g = (int)(g1 + (g2-g1)*t), b = (int)(b1 + (b2-b1)*t);
    char buf[8]; snprintf(buf, sizeof(buf), "#%02x%02x%02x", r,g,b);
    return v_str(buf);
}

/* ========================= ZAMAN (ek) ========================= */

#define TIMEPART(nm, field) \
static Value bi_##nm(Value *args, int argc, int *err, char *errmsg) { \
    (void)args; (void)argc; OK time_t t = time(NULL); struct tm *tmv = localtime(&t); return v_num(field); \
}
TIMEPART(year_now, tmv->tm_year + 1900)
TIMEPART(month_now, tmv->tm_mon + 1)
TIMEPART(day_now, tmv->tm_mday)
TIMEPART(hour_now, tmv->tm_hour)
TIMEPART(minute_now, tmv->tm_min)
TIMEPART(second_now, tmv->tm_sec)
TIMEPART(weekday_now, tmv->tm_wday)

/* ========================= RASTGELE (ek) ========================= */

static Value bi_random_bool(Value *args, int argc, int *err, char *errmsg) {
    OK double p = HAS(0) ? NA(0) : 0.5; return v_bool(rnd01() < p);
}
static Value bi_random_choice(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1 || args[0].type != T_ARR || args[0].obj->arr.count == 0) return v_null();
    int i = (int)(xorshift() % (unsigned long)args[0].obj->arr.count);
    return args[0].obj->arr.items[i];
}
static Value bi_random_float(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(rnd01());
    double lo = NA(0), hi = NA(1); return v_num(lo + rnd01()*(hi-lo));
}
static Value bi_dice_roll(Value *args, int argc, int *err, char *errmsg) {
    OK int sides = HAS(0) ? (int)NA(0) : 6; if (sides < 1) sides = 6;
    return v_num(1 + (int)(xorshift() % (unsigned long)sides));
}
static Value bi_coin_flip(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return v_bool(xorshift() % 2 == 0);
}

/* ========================= CIHAZ (Termux API) ========================= */

static Value bi_vibrate(Value *args, int argc, int *err, char *errmsg) {
    OK int ms = HAS(0) ? (int)NA(0) : 200;
    char cmd[128]; snprintf(cmd, sizeof(cmd), "termux-vibrate -d %d >/dev/null 2>&1", ms);
    system(cmd); return v_null();
}
static Value bi_toast(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    char cmd[1024]; snprintf(cmd, sizeof(cmd), "termux-toast \"%s\" >/dev/null 2>&1", SA(0));
    system(cmd); return v_null();
}
static Value bi_battery_status(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-battery-status 2>/dev/null");
}
static Value bi_clipboard_get(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-clipboard-get 2>/dev/null");
}
static Value bi_clipboard_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    FILE *p = popen("termux-clipboard-set 2>/dev/null", "w");
    if (p) { fputs(SA(0), p); pclose(p); }
    return v_null();
}
static Value bi_notify(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_null();
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "termux-notification --title \"%s\" --content \"%s\" >/dev/null 2>&1", SA(0), SA(1));
    system(cmd); return v_null();
}
static Value bi_get_location(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-location 2>/dev/null");
}
static Value bi_volume_get(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-volume 2>/dev/null");
}
static Value bi_volume_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_null();
    char cmd[128]; snprintf(cmd, sizeof(cmd), "termux-volume %s %d >/dev/null 2>&1", SA(0), (int)NA(1));
    system(cmd); return v_null();
}
static Value bi_brightness_set(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_null();
    char cmd[64]; snprintf(cmd, sizeof(cmd), "termux-brightness %d >/dev/null 2>&1", (int)NA(0));
    system(cmd); return v_null();
}
static Value bi_torch_on(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK system("termux-torch on >/dev/null 2>&1"); return v_null();
}
static Value bi_torch_off(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK system("termux-torch off >/dev/null 2>&1"); return v_null();
}
static Value bi_wifi_info(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-wifi-connectioninfo 2>/dev/null");
}
static Value bi_telephony_info(Value *args, int argc, int *err, char *errmsg) {
    (void)args; (void)argc; OK return popen_capture("termux-telephony-deviceinfo 2>/dev/null");
}

/* ========================= EK GRUP (tarih/metin/donusum) ========================= */

static Value bi_is_leap_year(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_bool(0);
    long long y = (long long)NA(0);
    return v_bool((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0));
}
static Value bi_days_in_month(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_num(30);
    int y = (int)NA(0), m = (int)NA(1);
    static const int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (m < 1 || m > 12) return v_num(30);
    int d = days[m-1];
    if (m == 2 && ((y%4==0 && y%100!=0) || y%400==0)) d = 29;
    return v_num(d);
}
static Value bi_int_to_roman(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    int n = (int)NA(0);
    if (n <= 0 || n > 3999) return v_str("");
    static const int vals[] = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
    static const char *syms[] = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
    char buf[64] = {0};
    for (int i = 0; i < 13; i++) while (n >= vals[i]) { strcat(buf, syms[i]); n -= vals[i]; }
    return v_str(buf);
}
static int roman_char_val(char c) {
    switch (toupper((unsigned char)c)) {
        case 'I': return 1; case 'V': return 5; case 'X': return 10; case 'L': return 50;
        case 'C': return 100; case 'D': return 500; case 'M': return 1000; default: return 0;
    }
}
static Value bi_roman_to_int(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0);
    const char *s = SA(0);
    int total = 0, n = (int)strlen(s);
    for (int i = 0; i < n; i++) {
        int cur = roman_char_val(s[i]);
        int next = i+1 < n ? roman_char_val(s[i+1]) : 0;
        if (cur < next) total -= cur; else total += cur;
    }
    return v_num(total);
}
static Value bi_reverse_words(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    Value w = bi_words(args, 1, err, errmsg);
    char *out = (char*)malloc(strlen(SA(0)) + 1);
    out[0] = 0;
    for (int i = w.obj->arr.count - 1; i >= 0; i--) {
        strcat(out, w.obj->arr.items[i].obj->str.chars);
        if (i != 0) strcat(out, " ");
    }
    return v_str_take(out);
}
static Value bi_is_anagram(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 2) return v_bool(0);
    int counts[256] = {0};
    const char *a = SA(0), *b = SA(1);
    for (const char *p = a; *p; p++) if (isalnum((unsigned char)*p)) counts[tolower((unsigned char)*p)]++;
    for (const char *p = b; *p; p++) if (isalnum((unsigned char)*p)) counts[tolower((unsigned char)*p)]--;
    for (int i = 0; i < 256; i++) if (counts[i] != 0) return v_bool(0);
    return v_bool(1);
}
static Value bi_longest_word(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("");
    Value w = bi_words(args, 1, err, errmsg);
    if (w.obj->arr.count == 0) return v_str("");
    Value best = w.obj->arr.items[0];
    for (int i = 1; i < w.obj->arr.count; i++)
        if (w.obj->arr.items[i].obj->str.len > best.obj->str.len) best = w.obj->arr.items[i];
    return best;
}
static Value bi_celsius_to_fahrenheit(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(NA(0) * 9.0/5.0 + 32);
}
static Value bi_fahrenheit_to_celsius(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num((NA(0) - 32) * 5.0/9.0);
}
static Value bi_km_to_miles(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(NA(0) * 0.621371);
}
static Value bi_miles_to_km(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); return v_num(NA(0) * 1.60934);
}
static Value bi_square(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_num(0); double x = NA(0); return v_num(x * x);
}
static Value bi_seconds_to_hms(Value *args, int argc, int *err, char *errmsg) {
    OK if (argc < 1) return v_str("00:00:00");
    long long s = (long long)NA(0);
    int h = (int)(s / 3600), m = (int)((s % 3600) / 60), sec = (int)(s % 60);
    char buf[32]; snprintf(buf, sizeof(buf), "%02d:%02d:%02d", h, m, sec);
    return v_str(buf);
}

/* ========================= KAYIT TABLOSU ========================= */

#define REG(nm) { #nm, bi_##nm }

BuiltinEntry g_builtins[] = {
    /* matematik - libm sarmalayicilari */
    REG(sqrt), REG(sin), REG(cos), REG(tan), REG(asin), REG(acos), REG(atan),
    REG(sinh), REG(cosh), REG(tanh), REG(log), REG(log2), REG(log10), REG(log1p),
    REG(exp), REG(exp2), REG(cbrt), REG(abs), REG(floor), REG(ceil), REG(round),
    REG(trunc), REG(expm1), REG(erf), REG(erfc), REG(tgamma),
    REG(pow), REG(atan2), REG(fmod), REG(hypot), REG(copysign), REG(fmax), REG(fmin),
    REG(fdim), REG(nextafter),
    /* matematik - ozel */
    REG(sign), REG(clamp), REG(clamp01), REG(min), REG(max), REG(mod), REG(gcd), REG(lcm),
    REG(factorial), REG(is_prime), REG(deg2rad), REG(rad2deg), REG(random), REG(random_range),
    REG(random_seed), REG(nth_root), REG(is_even), REG(is_odd), REG(is_power_of_two),
    REG(digit_sum), REG(reverse_number), REG(to_binary_string), REG(to_hex_string),
    REG(to_octal_string), REG(from_base), REG(pi), REG(e), REG(lerp), REG(inverse_lerp),
    REG(lerp_angle),
    /* metin */
    REG(upper), REG(lower), REG(trim), REG(ltrim), REG(rtrim), REG(split), REG(replace),
    REG(replace_all), REG(substr), REG(last_index_of), REG(starts_with), REG(ends_with),
    REG(repeat), REG(pad_left), REG(pad_right), REG(format), REG(capitalize), REG(title_case),
    REG(count_occurrences), REG(is_numeric), REG(is_alpha), REG(is_alnum), REG(is_digit),
    REG(is_space), REG(is_upper), REG(is_lower), REG(char_at), REG(char_code_at),
    REG(from_char_code), REG(strip_chars), REG(insert_at), REG(remove_range), REG(to_int),
    REG(to_float), REG(words), REG(lines), REG(equals_ignore_case), REG(left), REG(right),
    REG(center), REG(string_compare), REG(slugify), REG(url_encode), REG(url_decode),
    REG(escape_html), REG(unescape_html), REG(camel_case), REG(snake_case), REG(kebab_case),
    REG(count_words), REG(count_lines), REG(is_palindrome),
    /* ortak (polimorfik) */
    REG(len), REG(first), REG(last), REG(slice), REG(copy), REG(reverse), REG(contains),
    REG(index_of), REG(concat), REG(to_string), REG(is_empty),
    /* dizi */
    REG(push), REG(pop), REG(shift), REG(unshift), REG(get), REG(set), REG(splice),
    REG(sort), REG(sort_desc), REG(map), REG(filter), REG(reduce), REG(find), REG(find_index),
    REG(some), REG(every), REG(flatten), REG(unique), REG(fill), REG(range), REG(sum), REG(avg),
    REG(arr_min), REG(arr_max), REG(clear), REG(insert), REG(remove_at), REG(swap), REG(shuffle),
    REG(count_if), REG(array_new), REG(zip), REG(chunk), REG(rotate_left), REG(rotate_right),
    REG(partition), REG(group_by), REG(array_equals), REG(array_min_index), REG(array_max_index),
    REG(flatten_deep), REG(array_sum_squares),
    /* harita */
    REG(map_new), REG(map_set), REG(map_get), REG(map_has), REG(map_delete), REG(map_keys),
    REG(map_values), REG(map_size), REG(map_clear), REG(map_merge), REG(map_copy),
    REG(map_to_string), REG(map_each), REG(char_frequency),
    /* g/c - dosya/sistem */
    REG(print), REG(println), REG(input), REG(sistem), REG(file_read), REG(file_write),
    REG(file_append), REG(file_append_line), REG(file_exists), REG(file_delete), REG(file_size),
    REG(file_copy), REG(file_rename), REG(dir_list), REG(dir_create), REG(dir_exists),
    REG(is_directory), REG(is_file), REG(env_get), REG(env_set), REG(exit), REG(sleep_ms),
    REG(time_now), REG(clock_ms), REG(date_string), REG(format_time), REG(current_dir),
    REG(path_join), REG(path_basename), REG(path_dirname), REG(path_extension), REG(cpu_count),
    REG(file_lines), REG(list_env_vars), REG(ping_host), REG(download_file), REG(http_get),
    /* tur/donusum */
    REG(typeof), REG(is_null), REG(is_bool), REG(is_num), REG(is_str), REG(is_array),
    REG(is_map), REG(is_func), REG(is_native), REG(to_bool), REG(to_num), REG(clone),
    REG(deep_equals), REG(assert),
    /* bit islemleri */
    REG(band), REG(bor), REG(bxor), REG(bnot), REG(bshl), REG(bshr), REG(bit_count),
    /* json */
    REG(json_encode), REG(json_decode),
    /* hash/kodlama */
    REG(base64_encode), REG(base64_decode), REG(hash_string), REG(checksum), REG(uuid4),
    /* hata ayiklama/cesitli */
    REG(debug_print), REG(panic), REG(version), REG(identity), REG(noop),
    REG(benchmark_start), REG(benchmark_end), REG(timestamp_diff),
    /* istatistik */
    REG(median), REG(variance), REG(stddev), REG(mode), REG(percentile), REG(normalize),
    REG(cumsum), REG(product), REG(range_of),
    /* geometri */
    REG(distance_2d), REG(distance_3d), REG(dot_product), REG(cross_product_2d),
    REG(magnitude_2d), REG(normalize_vector_2d), REG(angle_between), REG(deg_to_compass),
    /* renk */
    REG(rgb_to_hex), REG(hex_to_rgb), REG(rgb_to_hsv), REG(hsv_to_rgb), REG(lighten),
    REG(darken), REG(blend_colors),
    /* zaman (ek) */
    REG(year_now), REG(month_now), REG(day_now), REG(hour_now), REG(minute_now),
    REG(second_now), REG(weekday_now),
    /* rastgele (ek) */
    REG(random_bool), REG(random_choice), REG(random_float), REG(dice_roll), REG(coin_flip),
    /* cihaz (Termux API) */
    REG(vibrate), REG(toast), REG(battery_status), REG(clipboard_get), REG(clipboard_set),
    REG(notify), REG(get_location), REG(volume_get), REG(volume_set), REG(brightness_set),
    REG(torch_on), REG(torch_off), REG(wifi_info), REG(telephony_info),
    /* ek grup */
    REG(is_leap_year), REG(days_in_month), REG(int_to_roman), REG(roman_to_int),
    REG(reverse_words), REG(is_anagram), REG(longest_word), REG(celsius_to_fahrenheit),
    REG(fahrenheit_to_celsius), REG(km_to_miles), REG(miles_to_km), REG(seconds_to_hms),
    REG(square),
};

int g_builtin_count = sizeof(g_builtins) / sizeof(g_builtins[0]);

int builtins_total_count(void) { return g_builtin_count; }

void builtins_register(Env *global) {
    for (int i = 0; i < g_builtin_count; i++) {
        env_set_local(global, g_builtins[i].name, v_native(g_builtins[i].name, g_builtins[i].fn));
    }
}
