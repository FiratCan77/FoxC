/* front.c - FoxC lexer + parser */
#include "foxc.h"
#include <ctype.h>

/* ================= LEXER ================= */

void lexer_init(Lexer *lx, const char *src) {
    lx->src = src;
    lx->pos = 0;
    lx->line = 1;
    lx->len = (int)strlen(src);
}

static char lx_peek(Lexer *lx) { return lx->pos < lx->len ? lx->src[lx->pos] : '\0'; }
static char lx_peek2(Lexer *lx) { return lx->pos + 1 < lx->len ? lx->src[lx->pos+1] : '\0'; }
static char lx_adv(Lexer *lx) {
    char c = lx->src[lx->pos++];
    if (c == '\n') lx->line++;
    return c;
}

static void skip_ws_comments(Lexer *lx) {
    for (;;) {
        char c = lx_peek(lx);
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') { lx_adv(lx); continue; }
        if (c == '/' && lx_peek2(lx) == '/') {
            while (lx_peek(lx) != '\n' && lx_peek(lx) != '\0') lx_adv(lx);
            continue;
        }
        if (c == '/' && lx_peek2(lx) == '*') {
            lx_adv(lx); lx_adv(lx);
            while (!(lx_peek(lx) == '*' && lx_peek2(lx) == '/') && lx_peek(lx) != '\0') lx_adv(lx);
            if (lx_peek(lx) != '\0') { lx_adv(lx); lx_adv(lx); }
            continue;
        }
        break;
    }
}

static Token mktok(TokType t, int line) {
    Token tok; tok.type = t; tok.text = NULL; tok.num = 0; tok.line = line;
    return tok;
}

static int kw_match(const char *s, const char *kw) { return strcmp(s, kw) == 0; }

static TokType ident_keyword(const char *s) {
    if (kw_match(s, "fn")) return TK_FN;
    if (kw_match(s, "var")) return TK_VAR;
    if (kw_match(s, "if")) return TK_IF;
    if (kw_match(s, "else")) return TK_ELSE;
    if (kw_match(s, "while")) return TK_WHILE;
    if (kw_match(s, "for")) return TK_FOR;
    if (kw_match(s, "return")) return TK_RETURN;
    if (kw_match(s, "true")) return TK_TRUE;
    if (kw_match(s, "false")) return TK_FALSE;
    if (kw_match(s, "null")) return TK_NULLTOK;
    if (kw_match(s, "break")) return TK_BREAK;
    if (kw_match(s, "continue")) return TK_CONTINUE;
    if (kw_match(s, "and")) return TK_AND;
    if (kw_match(s, "or")) return TK_OR;
    if (kw_match(s, "not")) return TK_NOT;
    return TK_IDENT;
}

Token lexer_next(Lexer *lx) {
    skip_ws_comments(lx);
    int line = lx->line;
    if (lx->pos >= lx->len) return mktok(TK_EOF, line);
    char c = lx_peek(lx);

    if (isdigit((unsigned char)c) || (c == '.' && isdigit((unsigned char)lx_peek2(lx)))) {
        int start = lx->pos;
        while (isdigit((unsigned char)lx_peek(lx))) lx_adv(lx);
        if (lx_peek(lx) == '.' && isdigit((unsigned char)lx_peek2(lx))) {
            lx_adv(lx);
            while (isdigit((unsigned char)lx_peek(lx))) lx_adv(lx);
        }
        if (lx_peek(lx) == 'e' || lx_peek(lx) == 'E') {
            lx_adv(lx);
            if (lx_peek(lx) == '+' || lx_peek(lx) == '-') lx_adv(lx);
            while (isdigit((unsigned char)lx_peek(lx))) lx_adv(lx);
        }
        int n = lx->pos - start;
        char *buf = (char*)malloc(n + 1);
        memcpy(buf, lx->src + start, n); buf[n] = '\0';
        Token t = mktok(TK_NUM, line);
        t.num = atof(buf);
        free(buf);
        return t;
    }

    if (c == '"') {
        lx_adv(lx);
        char *buf = (char*)malloc(256);
        int cap = 256, n = 0;
        while (lx_peek(lx) != '"' && lx_peek(lx) != '\0') {
            char ch = lx_adv(lx);
            if (ch == '\\') {
                char esc = lx_adv(lx);
                switch (esc) {
                    case 'n': ch = '\n'; break;
                    case 't': ch = '\t'; break;
                    case 'r': ch = '\r'; break;
                    case '"': ch = '"'; break;
                    case '\\': ch = '\\'; break;
                    case '0': ch = '\0'; break;
                    default: ch = esc; break;
                }
            }
            if (n + 1 >= cap) { cap *= 2; buf = (char*)realloc(buf, cap); }
            buf[n++] = ch;
        }
        if (lx_peek(lx) == '"') lx_adv(lx);
        buf[n] = '\0';
        Token t = mktok(TK_STR, line);
        t.text = buf;
        return t;
    }

    if (isalpha((unsigned char)c) || c == '_') {
        int start = lx->pos;
        while (isalnum((unsigned char)lx_peek(lx)) || lx_peek(lx) == '_') lx_adv(lx);
        int n = lx->pos - start;
        char *buf = (char*)malloc(n + 1);
        memcpy(buf, lx->src + start, n); buf[n] = '\0';
        TokType kw = ident_keyword(buf);
        Token t = mktok(kw, line);
        if (kw == TK_IDENT) t.text = buf; else free(buf);
        return t;
    }

    lx_adv(lx);
    switch (c) {
        case '{': return mktok(TK_LBRACE, line);
        case '}': return mktok(TK_RBRACE, line);
        case '(': return mktok(TK_LPAREN, line);
        case ')': return mktok(TK_RPAREN, line);
        case '[': return mktok(TK_LBRACKET, line);
        case ']': return mktok(TK_RBRACKET, line);
        case ':': return mktok(TK_COLON, line);
        case ',': return mktok(TK_COMMA, line);
        case ';': return mktok(TK_SEMI, line);
        case '.': return mktok(TK_DOT, line);
        case '%': return mktok(TK_PERCENT, line);
        case '+':
            if (lx_peek(lx) == '+') { lx_adv(lx); return mktok(TK_PLUSPLUS, line); }
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_PLUSEQ, line); }
            return mktok(TK_PLUS, line);
        case '-':
            if (lx_peek(lx) == '-') { lx_adv(lx); return mktok(TK_MINUSMINUS, line); }
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_MINUSEQ, line); }
            return mktok(TK_MINUS, line);
        case '*':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_STAREQ, line); }
            return mktok(TK_STAR, line);
        case '/':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_SLASHEQ, line); }
            return mktok(TK_SLASH, line);
        case '=':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_EQ, line); }
            return mktok(TK_ASSIGN, line);
        case '!':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_NEQ, line); }
            return mktok(TK_NOT, line);
        case '<':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_LE, line); }
            return mktok(TK_LT, line);
        case '>':
            if (lx_peek(lx) == '=') { lx_adv(lx); return mktok(TK_GE, line); }
            return mktok(TK_GT, line);
        case '&':
            if (lx_peek(lx) == '&') { lx_adv(lx); return mktok(TK_AND, line); }
            break;
        case '|':
            if (lx_peek(lx) == '|') { lx_adv(lx); return mktok(TK_OR, line); }
            break;
    }
    fprintf(stderr, "FoxC: satir %d - bilinmeyen karakter '%c'\n", line, c);
    exit(1);
}

/* ================= AST helpers ================= */

Node *node_new(NodeType t) {
    Node *n = (Node*)calloc(1, sizeof(Node));
    n->type = t;
    return n;
}

void node_list_push(Node *n, Node *child) {
    if (n->listcount + 1 > n->listcap) {
        n->listcap = n->listcap ? n->listcap * 2 : 4;
        n->list = (Node**)realloc(n->list, sizeof(Node*) * n->listcap);
    }
    n->list[n->listcount++] = child;
}

/* ================= PARSER ================= */

static void p_advance(Parser *p) {
    p->prev = p->cur;
    p->cur = lexer_next(&p->lx);
}

void parser_init(Parser *p, const char *src) {
    lexer_init(&p->lx, src);
    p->cur.type = TK_EOF;
    p_advance(p);
}

static int check(Parser *p, TokType t) { return p->cur.type == t; }

static Token consume(Parser *p, TokType t, const char *msg) {
    if (p->cur.type != t) {
        fprintf(stderr, "FoxC ayristirma hatasi (satir %d): %s\n", p->cur.line, msg);
        exit(1);
    }
    Token tok = p->cur;
    p_advance(p);
    return tok;
}

static int match(Parser *p, TokType t) {
    if (check(p, t)) { p_advance(p); return 1; }
    return 0;
}

static Node *parse_expr(Parser *p);
static Node *parse_statement(Parser *p);
static Node *parse_block(Parser *p);

static Node *parse_primary(Parser *p) {
    Token t = p->cur;
    if (match(p, TK_NUM)) {
        Node *n = node_new(N_NUM); n->num = t.num; n->line = t.line; return n;
    }
    if (match(p, TK_STR)) {
        Node *n = node_new(N_STR); n->str = t.text; n->line = t.line; return n;
    }
    if (match(p, TK_TRUE)) { Node *n = node_new(N_BOOL); n->num = 1; return n; }
    if (match(p, TK_FALSE)) { Node *n = node_new(N_BOOL); n->num = 0; return n; }
    if (match(p, TK_NULLTOK)) { return node_new(N_NULL); }
    if (match(p, TK_IDENT)) {
        Node *n = node_new(N_IDENT); n->str = t.text; n->line = t.line; return n;
    }
    if (match(p, TK_LPAREN)) {
        Node *e = parse_expr(p);
        consume(p, TK_RPAREN, "')' bekleniyordu");
        return e;
    }
    if (match(p, TK_LBRACKET)) {
        Node *n = node_new(N_ARRLIT); n->line = t.line;
        if (!check(p, TK_RBRACKET)) {
            node_list_push(n, parse_expr(p));
            while (match(p, TK_COMMA)) {
                if (check(p, TK_RBRACKET)) break;
                node_list_push(n, parse_expr(p));
            }
        }
        consume(p, TK_RBRACKET, "']' bekleniyordu");
        return n;
    }
    if (match(p, TK_LBRACE)) {
        /* harita (map) literali: { "anahtar": deger, ... } */
        Node *n = node_new(N_MAPLIT); n->line = t.line;
        if (!check(p, TK_RBRACE)) {
            for (;;) {
                Node *key = parse_expr(p);
                consume(p, TK_COLON, "':' bekleniyordu (harita anahtar-deger)");
                Node *val = parse_expr(p);
                Node *pair = node_new(N_BLOCK); /* reuse as generic pair holder */
                pair->a = key; pair->b = val;
                node_list_push(n, pair);
                if (!match(p, TK_COMMA)) break;
                if (check(p, TK_RBRACE)) break;
            }
        }
        consume(p, TK_RBRACE, "'}' bekleniyordu (harita sonu)");
        return n;
    }
    if (match(p, TK_FN)) {
        /* anonim fonksiyon ifadesi: fn(a, b) { ... } */
        Node *n = node_new(N_FUNCEXPR); n->line = t.line;
        consume(p, TK_LPAREN, "'(' bekleniyordu");
        if (!check(p, TK_RPAREN)) {
            Token pt = consume(p, TK_IDENT, "parametre adi bekleniyordu");
            Node *pn = node_new(N_IDENT); pn->str = pt.text;
            node_list_push(n, pn);
            while (match(p, TK_COMMA)) {
                pt = consume(p, TK_IDENT, "parametre adi bekleniyordu");
                pn = node_new(N_IDENT); pn->str = pt.text;
                node_list_push(n, pn);
            }
        }
        consume(p, TK_RPAREN, "')' bekleniyordu");
        n->a = parse_block(p);
        return n;
    }
    fprintf(stderr, "FoxC ayristirma hatasi (satir %d): beklenmeyen token\n", t.line);
    exit(1);
}

static Node *parse_call_index_member(Parser *p) {
    Node *n = parse_primary(p);
    for (;;) {
        if (match(p, TK_LPAREN)) {
            Node *call = node_new(N_CALL);
            call->a = n;
            if (!check(p, TK_RPAREN)) {
                node_list_push(call, parse_expr(p));
                while (match(p, TK_COMMA)) node_list_push(call, parse_expr(p));
            }
            consume(p, TK_RPAREN, "')' bekleniyordu (fonksiyon cagrisi)");
            n = call;
        } else if (match(p, TK_LBRACKET)) {
            Node *idx = node_new(N_INDEX);
            idx->a = n;
            idx->b = parse_expr(p);
            consume(p, TK_RBRACKET, "']' bekleniyordu");
            n = idx;
        } else if (match(p, TK_DOT)) {
            Token name = consume(p, TK_IDENT, "alan adi bekleniyordu");
            Node *mem = node_new(N_MEMBER);
            mem->a = n;
            mem->str = name.text;
            n = mem;
        } else break;
    }
    return n;
}

static Node *parse_unary(Parser *p) {
    if (check(p, TK_MINUS) || check(p, TK_NOT) || check(p, TK_PLUS)) {
        Token op = p->cur; p_advance(p);
        Node *n = node_new(N_UNOP);
        n->str = (op.type == TK_MINUS) ? "-" : (op.type == TK_PLUS) ? "+" : "!";
        n->a = parse_unary(p);
        n->line = op.line;
        return n;
    }
    return parse_call_index_member(p);
}

static Node *bin(const char *op, Node *a, Node *b) {
    Node *n = node_new(N_BINOP);
    n->str = (char*)op; n->a = a; n->b = b;
    return n;
}
static Node *logical(const char *op, Node *a, Node *b) {
    Node *n = node_new(N_LOGICAL);
    n->str = (char*)op; n->a = a; n->b = b;
    return n;
}

static Node *parse_mul(Parser *p) {
    Node *n = parse_unary(p);
    for (;;) {
        if (match(p, TK_STAR)) n = bin("*", n, parse_unary(p));
        else if (match(p, TK_SLASH)) n = bin("/", n, parse_unary(p));
        else if (match(p, TK_PERCENT)) n = bin("%", n, parse_unary(p));
        else break;
    }
    return n;
}
static Node *parse_add(Parser *p) {
    Node *n = parse_mul(p);
    for (;;) {
        if (match(p, TK_PLUS)) n = bin("+", n, parse_mul(p));
        else if (match(p, TK_MINUS)) n = bin("-", n, parse_mul(p));
        else break;
    }
    return n;
}
static Node *parse_compare(Parser *p) {
    Node *n = parse_add(p);
    for (;;) {
        if (match(p, TK_LT)) n = bin("<", n, parse_add(p));
        else if (match(p, TK_GT)) n = bin(">", n, parse_add(p));
        else if (match(p, TK_LE)) n = bin("<=", n, parse_add(p));
        else if (match(p, TK_GE)) n = bin(">=", n, parse_add(p));
        else break;
    }
    return n;
}
static Node *parse_equality(Parser *p) {
    Node *n = parse_compare(p);
    for (;;) {
        if (match(p, TK_EQ)) n = bin("==", n, parse_compare(p));
        else if (match(p, TK_NEQ)) n = bin("!=", n, parse_compare(p));
        else break;
    }
    return n;
}
static Node *parse_and(Parser *p) {
    Node *n = parse_equality(p);
    while (match(p, TK_AND)) n = logical("&&", n, parse_equality(p));
    return n;
}
static Node *parse_or(Parser *p) {
    Node *n = parse_and(p);
    while (match(p, TK_OR)) n = logical("||", n, parse_and(p));
    return n;
}

static Node *parse_assign(Parser *p) {
    Node *n = parse_or(p);
    if (check(p, TK_ASSIGN) || check(p, TK_PLUSEQ) || check(p, TK_MINUSEQ) ||
        check(p, TK_STAREQ) || check(p, TK_SLASHEQ)) {
        TokType optype = p->cur.type;
        p_advance(p);
        Node *val = parse_assign(p);
        if (optype != TK_ASSIGN) {
            const char *op = optype == TK_PLUSEQ ? "+" : optype == TK_MINUSEQ ? "-" :
                              optype == TK_STAREQ ? "*" : "/";
            val = bin(op, n, val);
        }
        if (n->type == N_IDENT) {
            Node *as = node_new(N_ASSIGN);
            as->str = n->str; as->a = val;
            return as;
        } else if (n->type == N_INDEX) {
            Node *as = node_new(N_INDEXASSIGN);
            as->a = n->a; as->b = n->b; as->c = val;
            return as;
        } else if (n->type == N_MEMBER) {
            Node *as = node_new(N_MEMBERASSIGN);
            as->a = n->a; as->str = n->str; as->c = val;
            return as;
        }
        fprintf(stderr, "FoxC hatasi: atama hedefi gecersiz (satir %d)\n", p->prev.line);
        exit(1);
    }
    return n;
}

static Node *parse_expr(Parser *p) { return parse_assign(p); }

static Node *parse_block(Parser *p) {
    consume(p, TK_LBRACE, "'{' bekleniyordu");
    Node *blk = node_new(N_BLOCK);
    while (!check(p, TK_RBRACE) && !check(p, TK_EOF)) {
        node_list_push(blk, parse_statement(p));
    }
    consume(p, TK_RBRACE, "'}' bekleniyordu");
    return blk;
}

static Node *parse_statement(Parser *p) {
    int line = p->cur.line;
    if (check(p, TK_LBRACE)) return parse_block(p);

    if (match(p, TK_VAR)) {
        Token name = consume(p, TK_IDENT, "degisken adi bekleniyordu");
        Node *n = node_new(N_VARDECL); n->str = name.text; n->line = line;
        if (match(p, TK_ASSIGN)) n->a = parse_expr(p);
        match(p, TK_SEMI);
        return n;
    }
    if (match(p, TK_FN)) {
        Token name = consume(p, TK_IDENT, "fonksiyon adi bekleniyordu");
        Node *n = node_new(N_FUNCDECL); n->str = name.text; n->line = line;
        consume(p, TK_LPAREN, "'(' bekleniyordu");
        if (!check(p, TK_RPAREN)) {
            Token pt = consume(p, TK_IDENT, "parametre adi bekleniyordu");
            Node *pn = node_new(N_IDENT); pn->str = pt.text;
            node_list_push(n, pn);
            while (match(p, TK_COMMA)) {
                pt = consume(p, TK_IDENT, "parametre adi bekleniyordu");
                pn = node_new(N_IDENT); pn->str = pt.text;
                node_list_push(n, pn);
            }
        }
        consume(p, TK_RPAREN, "')' bekleniyordu");
        n->a = parse_block(p);
        return n;
    }
    if (match(p, TK_IF)) {
        Node *n = node_new(N_IF); n->line = line;
        consume(p, TK_LPAREN, "'(' bekleniyordu");
        n->a = parse_expr(p);
        consume(p, TK_RPAREN, "')' bekleniyordu");
        n->b = parse_block(p);
        if (match(p, TK_ELSE)) {
            if (check(p, TK_IF)) n->c = parse_statement(p);
            else n->c = parse_block(p);
        }
        return n;
    }
    if (match(p, TK_WHILE)) {
        Node *n = node_new(N_WHILE); n->line = line;
        consume(p, TK_LPAREN, "'(' bekleniyordu");
        n->a = parse_expr(p);
        consume(p, TK_RPAREN, "')' bekleniyordu");
        n->b = parse_block(p);
        return n;
    }
    if (match(p, TK_FOR)) {
        consume(p, TK_LPAREN, "'(' bekleniyordu");
        Node *n = node_new(N_FOR); n->line = line;
        if (!check(p, TK_SEMI)) {
            if (check(p, TK_VAR)) n->a = parse_statement(p);
            else { n->a = node_new(N_EXPRSTMT); n->a->a = parse_expr(p); match(p, TK_SEMI); }
        } else match(p, TK_SEMI);
        if (!check(p, TK_SEMI)) n->b = parse_expr(p);
        consume(p, TK_SEMI, "';' bekleniyordu");
        if (!check(p, TK_RPAREN)) n->c = parse_expr(p);
        consume(p, TK_RPAREN, "')' bekleniyordu");
        n->d = parse_block(p);
        return n;
    }
    if (match(p, TK_RETURN)) {
        Node *n = node_new(N_RETURN); n->line = line;
        if (!check(p, TK_SEMI) && !check(p, TK_RBRACE)) n->a = parse_expr(p);
        match(p, TK_SEMI);
        return n;
    }
    if (match(p, TK_BREAK)) { match(p, TK_SEMI); return node_new(N_BREAK); }
    if (match(p, TK_CONTINUE)) { match(p, TK_SEMI); return node_new(N_CONTINUE); }

    Node *e = parse_expr(p);
    match(p, TK_SEMI);
    Node *stmt = node_new(N_EXPRSTMT);
    stmt->a = e; stmt->line = line;
    return stmt;
}

Node *parse_program(Parser *p) {
    Node *prog = node_new(N_PROGRAM);
    while (!check(p, TK_EOF)) node_list_push(prog, parse_statement(p));
    return prog;
}
