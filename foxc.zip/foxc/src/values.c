/* values.c - Value/Obj yardimcilari ve Environment */
#include "foxc.h"

unsigned long g_rng_state = 88172645463325252UL;

/* ---------- Environment ---------- */

Env *env_new(Env *parent) {
    Env *e = (Env*)calloc(1, sizeof(Env));
    e->parent = parent;
    e->cap = 8;
    e->vars = (VarSlot*)calloc(e->cap, sizeof(VarSlot));
    return e;
}

static int env_find_local(Env *e, const char *name) {
    for (int i = 0; i < e->count; i++)
        if (strcmp(e->vars[i].name, name) == 0) return i;
    return -1;
}

Value *env_get(Env *e, const char *name) {
    while (e) {
        int i = env_find_local(e, name);
        if (i >= 0) return &e->vars[i].val;
        e = e->parent;
    }
    return NULL;
}

void env_set_local(Env *e, const char *name, Value v) {
    int i = env_find_local(e, name);
    if (i >= 0) { e->vars[i].val = v; return; }
    if (e->count + 1 > e->cap) {
        e->cap *= 2;
        e->vars = (VarSlot*)realloc(e->vars, sizeof(VarSlot) * e->cap);
    }
    e->vars[e->count].name = strdup(name);
    e->vars[e->count].val = v;
    e->count++;
}

int env_assign(Env *e, const char *name, Value v) {
    Env *cur = e;
    while (cur) {
        int i = env_find_local(cur, name);
        if (i >= 0) { cur->vars[i].val = v; return 1; }
        cur = cur->parent;
    }
    return 0;
}

/* ---------- Value constructors ---------- */

Value v_null(void) { Value v; v.type = T_NULL; v.b=0; v.num=0; v.obj=NULL; return v; }
Value v_bool(int b) { Value v; v.type = T_BOOL; v.b = b ? 1 : 0; v.num=0; v.obj=NULL; return v; }
Value v_num(double d) { Value v; v.type = T_NUM; v.num = d; v.b=0; v.obj=NULL; return v; }

Value v_str_take(char *s) {
    Value v; v.type = T_STR; v.b=0; v.num=0;
    Obj *o = (Obj*)calloc(1, sizeof(Obj));
    o->type = T_STR;
    o->str.chars = s;
    o->str.len = (int)strlen(s);
    v.obj = o;
    return v;
}
Value v_str(const char *s) { return v_str_take(strdup(s ? s : "")); }

Value v_arr_new(void) {
    Value v; v.type = T_ARR; v.b=0; v.num=0;
    Obj *o = (Obj*)calloc(1, sizeof(Obj));
    o->type = T_ARR;
    o->arr.cap = 4;
    o->arr.items = (Value*)calloc(o->arr.cap, sizeof(Value));
    v.obj = o;
    return v;
}

Value v_map_new(void) {
    Value v; v.type = T_MAP; v.b=0; v.num=0;
    Obj *o = (Obj*)calloc(1, sizeof(Obj));
    o->type = T_MAP;
    o->map.cap = 4;
    o->map.entries = (MapEntry*)calloc(o->map.cap, sizeof(MapEntry));
    v.obj = o;
    return v;
}

Value v_func(FuncObj f) {
    Value v; v.type = T_FUNC; v.b=0; v.num=0;
    Obj *o = (Obj*)calloc(1, sizeof(Obj));
    o->type = T_FUNC;
    o->func = f;
    v.obj = o;
    return v;
}

Value v_native(const char *name, NativeFn fn) {
    Value v; v.type = T_NATIVE; v.b=0; v.num=0;
    Obj *o = (Obj*)calloc(1, sizeof(Obj));
    o->type = T_NATIVE;
    o->native.name = name;
    o->native.fn = fn;
    v.obj = o;
    return v;
}

/* ---------- Array helpers ---------- */

void arr_push(Obj *o, Value v) {
    if (o->arr.count + 1 > o->arr.cap) {
        o->arr.cap *= 2;
        o->arr.items = (Value*)realloc(o->arr.items, sizeof(Value) * o->arr.cap);
    }
    o->arr.items[o->arr.count++] = v;
}

Value arr_get(Obj *o, int idx) {
    if (idx < 0) idx += o->arr.count;
    if (idx < 0 || idx >= o->arr.count) return v_null();
    return o->arr.items[idx];
}

/* ---------- Map helpers ---------- */

void map_set(Obj *o, const char *key, Value v) {
    for (int i = 0; i < o->map.count; i++) {
        if (strcmp(o->map.entries[i].key, key) == 0) {
            *(o->map.entries[i].val) = v;
            return;
        }
    }
    if (o->map.count + 1 > o->map.cap) {
        o->map.cap *= 2;
        o->map.entries = (MapEntry*)realloc(o->map.entries, sizeof(MapEntry) * o->map.cap);
    }
    o->map.entries[o->map.count].key = strdup(key);
    o->map.entries[o->map.count].val = (Value*)malloc(sizeof(Value));
    *(o->map.entries[o->map.count].val) = v;
    o->map.count++;
}

Value *map_get(Obj *o, const char *key) {
    for (int i = 0; i < o->map.count; i++)
        if (strcmp(o->map.entries[i].key, key) == 0) return o->map.entries[i].val;
    return NULL;
}

/* ---------- generic helpers ---------- */

double value_num(Value v) {
    if (v.type == T_NUM) return v.num;
    if (v.type == T_BOOL) return v.b;
    if (v.type == T_STR) return atof(v.obj->str.chars);
    return 0;
}

int is_truthy(Value v) {
    switch (v.type) {
        case T_NULL: return 0;
        case T_BOOL: return v.b;
        case T_NUM: return v.num != 0;
        case T_STR: return v.obj->str.len > 0;
        case T_ARR: return v.obj->arr.count > 0;
        case T_MAP: return v.obj->map.count > 0;
        default: return 1;
    }
}

int values_equal(Value a, Value b) {
    if (a.type != b.type) {
        if (a.type == T_NUM && b.type == T_NUM) return a.num == b.num;
        return 0;
    }
    switch (a.type) {
        case T_NULL: return 1;
        case T_BOOL: return a.b == b.b;
        case T_NUM: return a.num == b.num;
        case T_STR: return strcmp(a.obj->str.chars, b.obj->str.chars) == 0;
        case T_ARR: {
            if (a.obj == b.obj) return 1;
            if (a.obj->arr.count != b.obj->arr.count) return 0;
            for (int i = 0; i < a.obj->arr.count; i++)
                if (!values_equal(a.obj->arr.items[i], b.obj->arr.items[i])) return 0;
            return 1;
        }
        case T_MAP: return a.obj == b.obj;
        default: return a.obj == b.obj;
    }
}

const char *type_name(Value v) {
    switch (v.type) {
        case T_NULL: return "null";
        case T_BOOL: return "bool";
        case T_NUM: return "sayi";
        case T_STR: return "metin";
        case T_ARR: return "dizi";
        case T_MAP: return "harita";
        case T_FUNC: return "fonksiyon";
        case T_NATIVE: return "yerlesik";
    }
    return "?";
}

char *value_to_cstring(Value v) {
    char buf[64];
    switch (v.type) {
        case T_NULL: return strdup("null");
        case T_BOOL: return strdup(v.b ? "true" : "false");
        case T_NUM:
            if (v.num == (long long)v.num && fabs(v.num) < 1e15)
                snprintf(buf, sizeof(buf), "%lld", (long long)v.num);
            else
                snprintf(buf, sizeof(buf), "%g", v.num);
            return strdup(buf);
        case T_STR: return strdup(v.obj->str.chars);
        case T_ARR: {
            size_t cap = 256, len = 0;
            char *out = (char*)malloc(cap);
            out[0] = '['; len = 1; out[len]=0;
            for (int i = 0; i < v.obj->arr.count; i++) {
                char *piece;
                Value it = v.obj->arr.items[i];
                if (it.type == T_STR) {
                    size_t need = strlen(it.obj->str.chars) + 3;
                    piece = (char*)malloc(need);
                    snprintf(piece, need, "\"%s\"", it.obj->str.chars);
                } else piece = value_to_cstring(it);
                size_t plen = strlen(piece);
                while (len + plen + 3 >= cap) { cap *= 2; out = (char*)realloc(out, cap); }
                memcpy(out + len, piece, plen); len += plen;
                free(piece);
                if (i != v.obj->arr.count - 1) { out[len++] = ','; out[len++] = ' '; }
                out[len] = 0;
            }
            out[len++] = ']'; out[len] = 0;
            return out;
        }
        case T_MAP: {
            size_t cap = 256, len = 0;
            char *out = (char*)malloc(cap);
            out[0] = '{'; len = 1; out[len]=0;
            for (int i = 0; i < v.obj->map.count; i++) {
                char *vs;
                Value vv = *(v.obj->map.entries[i].val);
                if (vv.type == T_STR) {
                    size_t need = strlen(vv.obj->str.chars) + 3;
                    vs = (char*)malloc(need);
                    snprintf(vs, need, "\"%s\"", vv.obj->str.chars);
                } else vs = value_to_cstring(vv);
                size_t need2 = strlen(v.obj->map.entries[i].key) + strlen(vs) + 8;
                char *piece = (char*)malloc(need2);
                snprintf(piece, need2, "\"%s\": %s", v.obj->map.entries[i].key, vs);
                free(vs);
                size_t plen = strlen(piece);
                while (len + plen + 3 >= cap) { cap *= 2; out = (char*)realloc(out, cap); }
                memcpy(out + len, piece, plen); len += plen;
                free(piece);
                if (i != v.obj->map.count - 1) { out[len++] = ','; out[len++] = ' '; }
                out[len] = 0;
            }
            out[len++] = '}'; out[len] = 0;
            return out;
        }
        case T_FUNC: {
            const char *nm = v.obj->func.name ? v.obj->func.name : "anonim";
            snprintf(buf, sizeof(buf), "<fonksiyon %s>", nm);
            return strdup(buf);
        }
        case T_NATIVE:
            snprintf(buf, sizeof(buf), "<yerlesik %s>", v.obj->native.name);
            return strdup(buf);
    }
    return strdup("");
}

void value_print(Value v, int newline) {
    char *s = value_to_cstring(v);
    fputs(s, stdout);
    if (newline) fputc('\n', stdout);
    free(s);
}
