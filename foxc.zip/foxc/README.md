# FoxC

C ile yazilmis, gelismis bir betik (scripting) programlama dili.
**320 yerlesik (built-in) fonksiyon** ile geliyor: matematik, metin, dizi,
harita, dosya/sistem, tur donusumu, bit islemleri, JSON, hash/kodlama,
istatistik, geometri, renk, zaman, rastgele sayi ve Termux cihaz
fonksiyonlari (titresim, toast, konum, pil, panoya kopyalama vb.).

## Sozdizimi

- Bloklar `{ }` ile yazilir.
- Metinler `"cift tirnak"` ile yazilir.
- Harita (sozluk) literalleri `{ "anahtar": deger }` seklindedir — `:` ayracini kullanir.
- C'ye yakin: `fn`, `var`, `if/else`, `while`, `for`, `return`, `break`, `continue`.

```foxc
fn topla(a, b) {
    return a + b;
}

var kisi = {
    "isim": "Fatih",
    "yas": 21,
    "yetenekler": ["C", "FoxC", "Termux"]
};

println("Toplam:", topla(3, 4));
println("isim:", kisi["isim"], "-", kisi.yas);

var kareler = map(range(1, 6), fn(x) { return x * x; });
println(kareler);
```

## Derleme

Standart Linux / Termux uzerinde, sadece `cc` (gcc/clang) ve libm yeterli,
baska hicbir bagimlilik yok:

```sh
make
./foxc examples/demo.foxc
```

Termux'ta:

```sh
pkg install clang make
make
./foxc examples/demo.foxc
```

Yerlesik fonksiyon sayisini gormek icin:

```sh
./foxc --count
```

## Dizin yapisi

- `src/foxc.h`      — ortak tur tanimlari (Value/Obj, Env, Lexer, Parser, AST)
- `src/front.c`     — lexer + recursive-descent parser
- `src/values.c`    — Value/Obj yardimcilari, Environment (degisken kapsamlari)
- `src/interp.c`    — agac-yurutmeli (tree-walking) yorumlayici
- `src/builtins.c`  — 320 yerlesik fonksiyon ve kayit tablosu
- `src/main.c`      — komut satiri giris noktasi
- `examples/`        — ornek betikler

## Yerlesik fonksiyon gruplari (ozet)

| Grup | Ornekler |
|---|---|
| Matematik | `sqrt, pow, sin, log, abs, clamp, gcd, lcm, factorial, is_prime, random, lerp, pi, e` |
| Metin | `upper, lower, trim, split, replace, substr, format, slugify, camel_case, is_palindrome` |
| Dizi | `push, pop, map, filter, reduce, sort, unique, flatten, chunk, group_by, shuffle` |
| Harita | `map_new, map_set, map_get, map_keys, map_values, map_merge, map_each` |
| Dosya/Sistem | `file_read, file_write, dir_list, sistem, env_get, time_now, http_get` |
| Tur | `typeof, is_num, is_str, to_bool, clone, deep_equals, assert` |
| Bit | `band, bor, bxor, bnot, bshl, bshr, bit_count` |
| JSON | `json_encode, json_decode` |
| Hash/Kodlama | `base64_encode, base64_decode, hash_string, uuid4` |
| Istatistik | `median, variance, stddev, mode, percentile, normalize` |
| Geometri | `distance_2d, dot_product, angle_between, deg_to_compass` |
| Renk | `rgb_to_hex, hex_to_rgb, rgb_to_hsv, lighten, darken, blend_colors` |
| Zaman | `year_now, month_now, weekday_now, format_time, seconds_to_hms` |
| Rastgele | `random, random_range, random_choice, dice_roll, coin_flip` |
| Cihaz (Termux API) | `vibrate, toast, battery_status, clipboard_get/set, notify, get_location` |

Termux API fonksiyonlari `termux-api` paketi kurulu degilse sessizce
hicbir sey yapmaz (hata vermez), bu yuzden normal Linux'ta da güvenle
calisir.

## Bilinen sinirlamalar (v1)

- Sayilar tek tip (double) olarak tutulur; ayri int/float turu yoktur.
- Cop toplayici (garbage collector) yoktur — bellek, program bitene kadar
  serbest birakilmaz (kisa/orta boy betikler icin sorun degildir).
- Sinif/nesne sistemi yok; harita (map) ve fonksiyonlarla benzer yapilar
  kurulabilir.
